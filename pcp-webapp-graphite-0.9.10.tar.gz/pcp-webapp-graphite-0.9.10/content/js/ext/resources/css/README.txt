2010-03-16 jwr:
The CSS file, yourtheme.css, is an exact copy of xtheme-blue.css. Feel free to edit the images inside the yourtheme image directory to build your custom theme--just remember to update your background-image file paths in yourtheme.css.

2006-11-21 jvs:
ext-all.css contains all of the other css files combined and stripped of comments (except themes).

