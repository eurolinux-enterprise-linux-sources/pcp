/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
!function(){"use strict";function e(e,t,a,i,n,r,o,s,l,c,p,d,u,h,m,g,f,v,y,b,w,k){var M=function(e,t){"undefined"!=typeof e&&(t.filter=e.filter)},C=[{name:"kernel.all.load",title:"Load Average",directive:"line-time-series",dataAttrName:"data",dataModelType:e,dataModelOptions:{name:"kernel.all.load"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"CPU"},{name:"kernel.all.runnable",title:"Runnable",directive:"line-time-series",dataAttrName:"data",dataModelType:e,dataModelOptions:{name:"kernel.all.runnable"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"CPU",attrs:{forcey:4,integer:!0}},{name:"kernel.all.cpu.sys",title:"CPU Utilization (System)",directive:"line-time-series",dataAttrName:"data",dataModelType:b,dataModelOptions:{name:"kernel.all.cpu.sys"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"CPU",attrs:{forcey:1,percentage:!0,integer:!1}},{name:"kernel.all.cpu.user",title:"CPU Utilization (User)",directive:"line-time-series",dataAttrName:"data",dataModelType:b,dataModelOptions:{name:"kernel.all.cpu.user"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"CPU",attrs:{forcey:1,percentage:!0,integer:!1}},{name:"kernel.all.cpu",title:"CPU Utilization",directive:"area-stacked-time-series",dataAttrName:"data",dataModelType:h,dataModelOptions:{name:"kernel.all.cpu"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"CPU",attrs:{forcey:1,percentage:!0,integer:!1}},{name:"kernel.percpu.cpu.sys",title:"Per-CPU Utilization (System)",directive:"line-time-series",dataAttrName:"data",dataModelType:b,dataModelOptions:{name:"kernel.percpu.cpu.sys"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"CPU",attrs:{forcey:1,percentage:!0,integer:!1}},{name:"kernel.percpu.cpu.user",title:"Per-CPU Utilization (User)",directive:"line-time-series",dataAttrName:"data",dataModelType:b,dataModelOptions:{name:"kernel.percpu.cpu.user"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"CPU",attrs:{forcey:1,percentage:!0,integer:!1}},{name:"kernel.percpu.cpu",title:"Per-CPU Utilization",directive:"line-time-series",dataAttrName:"data",dataModelType:m,dataModelOptions:{name:"kernel.percpu.cpu"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"CPU",attrs:{forcey:1,percentage:!0,integer:!1}},{name:"mem.util.free",title:"Memory Utilization (Free)",directive:"line-time-series",dataAttrName:"data",dataModelType:t,dataModelOptions:{name:"mem.util.free",conversionFunction:function(e){return e/1024/1024}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Memory"},{name:"mem.util.used",title:"Memory Utilization (Used)",directive:"line-time-series",dataAttrName:"data",dataModelType:t,dataModelOptions:{name:"mem.util.used",conversionFunction:function(e){return e/1024/1024}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Memory"},{name:"mem.util.cached",title:"Memory Utilization (Cached)",directive:"line-time-series",dataAttrName:"data",dataModelType:t,dataModelOptions:{name:"mem.util.cached",conversionFunction:function(e){return e/1024/1024}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Memory"},{name:"mem",title:"Memory Utilization",directive:"area-stacked-time-series",dataAttrName:"data",dataModelType:d,dataModelOptions:{name:"mem"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Memory",attrs:{percentage:!1,integer:!0}},{name:"network.interface.out.drops",title:"Network Drops (Out)",directive:"line-time-series",dataAttrName:"data",dataModelType:e,dataModelOptions:{name:"network.interface.out.drops"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Network",attrs:{forcey:10,percentage:!1,integer:!0}},{name:"network.interface.in.drops",title:"Network Drops (In)",directive:"line-time-series",dataAttrName:"data",dataModelType:e,dataModelOptions:{name:"network.interface.in.drops"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Network",attrs:{forcey:10,percentage:!1,integer:!0}},{name:"network.interface.drops",title:"Network Drops",directive:"line-time-series",dataAttrName:"data",dataModelType:g,dataModelOptions:{name:"network.interface.drops",metricDefinitions:{"{key} in":"network.interface.in.drops","{key} out":"network.interface.out.drops"}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Network",attrs:{forcey:10,percentage:!1,integer:!0}},{name:"network.tcpconn.established",title:"TCP Connections (Estabilished)",directive:"line-time-series",dataAttrName:"data",dataModelType:e,dataModelOptions:{name:"network.tcpconn.established"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Network",attrs:{percentage:!1,integer:!0}},{name:"network.tcpconn.time_wait",title:"TCP Connections (Time Wait)",directive:"line-time-series",dataAttrName:"data",dataModelType:e,dataModelOptions:{name:"network.tcpconn.time_wait"},enableVerticalResize:!1,size:{width:"50%",height:"250px"},group:"Network",attrs:{percentage:!1,integer:!0}},{name:"network.tcpconn.close_wait",title:"TCP Connections (Close Wait)",directive:"line-time-series",dataAttrName:"data",dataModelType:e,dataModelOptions:{name:"network.tcpconn.close_wait"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Network",attrs:{percentage:!1,integer:!0}},{name:"network.tcpconn",title:"TCP Connections",directive:"line-time-series",dataAttrName:"data",dataModelType:g,dataModelOptions:{name:"network.tcpconn",metricDefinitions:{established:"network.tcpconn.established",time_wait:"network.tcpconn.time_wait",close_wait:"network.tcpconn.close_wait"}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Network",attrs:{percentage:!1,integer:!0}},{name:"network.interface.bytes",title:"Network Throughput (kB)",directive:"line-time-series",dataAttrName:"data",dataModelType:u,dataModelOptions:{name:"network.interface.bytes"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Network",attrs:{percentage:!1,integer:!0},settingsModalOptions:{templateUrl:"app/components/customWidgetSettings/customWidgetSettings.html",controller:"CustomWidgetSettingsController"},hasLocalSettings:!0,onSettingsClose:M,filter:""},{name:"disk.iops",title:"Disk IOPS",directive:"line-time-series",dataAttrName:"data",dataModelType:f,dataModelOptions:{name:"disk.iops",metricDefinitions:{"{key} read":"disk.dev.read","{key} write":"disk.dev.write"}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Disk"},{name:"disk.bytes",title:"Disk Throughput (Bytes)",directive:"line-time-series",dataAttrName:"data",dataModelType:f,dataModelOptions:{name:"disk.bytes",metricDefinitions:{"{key} read":"disk.dev.read_bytes","{key} write":"disk.dev.write_bytes"}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Disk"},{name:"disk.dev.avactive",title:"Disk Utilization",directive:"line-time-series",dataAttrName:"data",dataModelType:b,dataModelOptions:{name:"disk.dev.avactive"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Disk",attrs:{forcey:1,percentage:!0,integer:!1}},{name:"kernel.all.pswitch",title:"Context Switches",directive:"line-time-series",dataAttrName:"data",dataModelType:a,dataModelOptions:{name:"kernel.all.pswitch"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"CPU",attrs:{percentage:!1,integer:!0}},{name:"mem.vmstat.pgfault",title:"Page Faults",directive:"area-stacked-time-series",dataAttrName:"data",dataModelType:f,dataModelOptions:{name:"mem.vmstat.pgfault",metricDefinitions:{"page faults":"mem.vmstat.pgfault","major page faults":"mem.vmstat.pgmajfault"}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Memory",attrs:{percentage:!1,integer:!0}},{name:"network.interface.packets",title:"Network Packets",directive:"line-time-series",dataAttrName:"data",dataModelType:f,dataModelOptions:{name:"network.interface.packets",metricDefinitions:{"{key} in":"network.interface.in.packets","{key} out":"network.interface.out.packets"}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Network",attrs:{percentage:!1,integer:!0},settingsModalOptions:{templateUrl:"app/components/customWidgetSettings/customWidgetSettings.html",controller:"CustomWidgetSettingsController"},hasLocalSettings:!0,onSettingsClose:M,filter:""},{name:"network.tcp.retrans",title:"Network Retransmits",directive:"line-time-series",dataAttrName:"data",dataModelType:f,dataModelOptions:{name:"network.tcp.retrans",metricDefinitions:{retranssegs:"network.tcp.retranssegs",timeouts:"network.tcp.timeouts",listendrops:"network.tcp.listendrops",fastretrans:"network.tcp.fastretrans",slowstartretrans:"network.tcp.slowstartretrans",synretrans:"network.tcp.synretrans"}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Network",attrs:{forcey:10,percentage:!1,integer:!0}},{name:"disk.dev.latency",title:"Disk Latency",directive:"line-time-series",dataAttrName:"data",dataModelType:y,dataModelOptions:{name:"disk.dev.latency"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Disk",attrs:{percentage:!1,integer:!0}}];return k.enableCpuFlameGraph&&C.push({name:"graph.flame.cpu",title:"CPU Flame Graph (task)",directive:"cpu-flame-graph",dataModelType:v,size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"CPU",settingsModalOptions:{templateUrl:"app/components/customWidgetHelp/customWidgetHelp.html",controller:"CustomWidgetHelpController"},hasLocalHelp:!0,isContainerAware:!0},{name:"graph.flame.cpu.task",title:"CPU Flame Graph (task)",directive:"cpu-flame-graph",dataModelType:v,size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Task",settingsModalOptions:{templateUrl:"app/components/customWidgetHelp/customWidgetHelp.html",controller:"CustomWidgetHelpController"},hasLocalHelp:!0,isContainerAware:!0},{name:"graph.flame.pnamecpu.task",title:"Package Name CPU Flame Graph (task)",directive:"p-name-cpu-flame-graph",dataModelType:v,size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Task",settingsModalOptions:{templateUrl:"app/components/customWidgetHelp/customWidgetHelp.html",controller:"CustomWidgetHelpController"},hasLocalHelp:!0,isContainerAware:!0},{name:"graph.flame.uninlined.task",title:"Uninlined CPU Flame Graph (task)",directive:"uninlined-cpu-flame-graph",dataModelType:v,size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Task",settingsModalOptions:{templateUrl:"app/components/customWidgetHelp/customWidgetHelp.html",controller:"CustomWidgetHelpController"},hasLocalHelp:!0,isContainerAware:!0},{name:"graph.flame.pagefault.task",title:"Page Fault Flame Graph (task)",directive:"pagefault-flame-graph",dataModelType:v,size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Task",settingsModalOptions:{templateUrl:"app/components/customWidgetHelp/customWidgetHelp.html",controller:"CustomWidgetHelpController"},hasLocalHelp:!0,isContainerAware:!0},{name:"graph.flame.diskio.task",title:"Disk I/O Flame Graph (task)",directive:"diskio-flame-graph",dataModelType:v,size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Task",settingsModalOptions:{templateUrl:"app/components/customWidgetHelp/customWidgetHelp.html",controller:"CustomWidgetHelpController"},hasLocalHelp:!0,isContainerAware:!0},{name:"graph.flame.ipc.task",title:"IPC Flame Graph (task)",directive:"ipc-flame-graph",dataModelType:v,size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Task",settingsModalOptions:{templateUrl:"app/components/customWidgetHelp/customWidgetHelp.html",controller:"CustomWidgetHelpController"},hasLocalHelp:!0,isContainerAware:!0},{name:"graph.flame.csw.task",title:"Context Switch Flame Graph (task)",directive:"csw-flame-graph",dataModelType:v,size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Task",settingsModalOptions:{templateUrl:"app/components/customWidgetHelp/customWidgetHelp.html",controller:"CustomWidgetHelpController"},hasLocalHelp:!0,hasHighOverhead:!0,isContainerAware:!1},{name:"graph.flame.offcpu.task",title:"Off-CPU Time Flame Graph (task)",directive:"off-c-p-u-flame-graph",dataModelType:v,size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Task",settingsModalOptions:{templateUrl:"app/components/customWidgetHelp/customWidgetHelp.html",controller:"CustomWidgetHelpController"},hasLocalHelp:!0,hasHighOverhead:!0,isContainerAware:!1},{name:"graph.flame.offwake.task",title:"Off-Wake Time Flame Graph (task)",directive:"off-wake-flame-graph",dataModelType:v,size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Task",settingsModalOptions:{templateUrl:"app/components/customWidgetHelp/customWidgetHelp.html",controller:"CustomWidgetHelpController"},hasLocalHelp:!0,hasHighOverhead:!0,isContainerAware:!1}),k.enableContainerWidgets&&C.push({name:"cgroup.cpuacct.usage",title:"Per-Container CPU Utilization",directive:"line-time-series",dataAttrName:"data",dataModelType:i,dataModelOptions:{name:"cgroup.cpuacct.usage"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Container",requireContainerFilter:!0,attrs:{forcey:1,percentage:!0,integer:!1}},{name:"cgroup.memory.usage",title:"Per-Container Memory Usage (Mb)",directive:"line-time-series",dataAttrName:"data",dataModelType:r,dataModelOptions:{name:"cgroup.memory.usage"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Container",attrs:{percentage:!1,integer:!0,forcey:10}},{name:"container.memory.usage",title:"Total Container Memory Usage (Mb)",directive:"area-stacked-time-series",dataAttrName:"data",dataModelType:o,dataModelOptions:{name:"container.memory.usage"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Container",attrs:{percentage:!1,integer:!0}},{name:"cgroup.memory.headroom",title:"Per-Container Memory Headroom (Mb)",directive:"line-time-series",dataAttrName:"data",dataModelType:p,dataModelOptions:{name:"cgroup.memory.headroom"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Container",requireContainerFilter:!0,attrs:{forcey:1,percentage:!1,integer:!0,area:!0}},{name:"cgroup.blkio.all.io_serviced",title:"Container Disk IOPS",directive:"line-time-series",dataAttrName:"data",dataModelType:c,dataModelOptions:{name:"cgroup.blkio.all.io_serviced",metricDefinitions:{"{key} read":"cgroup.blkio.all.io_serviced.read","{key} write":"cgroup.blkio.all.io_serviced.write"}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Container",attrs:{percentage:!1,integer:!0}},{name:"cgroup.blkio.all.io_service_bytes",title:"Container Disk Throughput (Bytes)",directive:"line-time-series",dataAttrName:"data",dataModelType:c,dataModelOptions:{name:"cgroup.blkio.all.io_service_bytes",metricDefinitions:{"{key} read":"cgroup.blkio.all.io_service_bytes.read","{key} write":"cgroup.blkio.all.io_service_bytes.write"}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Container",attrs:{percentage:!1,integer:!0}},{name:"cgroup.blkio.all.throttle.io_serviced",title:"Container Disk IOPS (Throttled)",directive:"line-time-series",dataAttrName:"data",dataModelType:c,dataModelOptions:{name:"cgroup.blkio.all.throttle.io_serviced",metricDefinitions:{"{key} read":"cgroup.blkio.all.throttle.io_serviced.read","{key} write":"cgroup.blkio.all.throttle.io_serviced.write"}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Container",attrs:{percentage:!1,integer:!0}},{name:"cgroup.blkio.all.throttle.io_service_bytes",title:"Container Disk Throughput (Throttled) (Bytes)",directive:"line-time-series",dataAttrName:"data",dataModelType:c,dataModelOptions:{name:"cgroup.blkio.all.throttle.io_service_bytes",metricDefinitions:{"{key} read":"cgroup.blkio.all.throttle.io_service_bytes.read","{key} write":"cgroup.blkio.all.throttle.io_service_bytes.write"}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Container",attrs:{percentage:!1,integer:!0}},{name:"cgroup.cpusched",title:"Per-Container CPU Scheduler",directive:"line-time-series",dataAttrName:"data",dataModelType:l,dataModelOptions:{name:"cgroup.cpusched",metricDefinitions:{"{key} shares":"cgroup.cpusched.shares","{key} periods":"cgroup.cpusched.periods"}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Container",attrs:{percentage:!1,integer:!0}},{name:"cgroup.cpuacct.headroom",title:"Per-Container CPU Headroom",directive:"line-time-series",dataAttrName:"data",dataModelType:n,dataModelOptions:{name:"cgroup.cpuacct.headroom"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Container",requireContainerFilter:!0,attrs:{forcey:1,percentage:!0,integer:!1,area:!0}},{name:"cgroup.cpusched.throttled_time",title:"Per-Container Throttled CPU",directive:"line-time-series",dataAttrName:"data",dataModelType:c,dataModelOptions:{name:"cgroup.cpusched.throttled_time",metricDefinitions:{"{key}":"cgroup.cpusched.throttled_time"}},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Container",attrs:{forcey:5,percentage:!1,integer:!0}},{name:"cgroup.memory.utilization",title:"Per-Container Memory Utilization",directive:"line-time-series",dataAttrName:"data",dataModelType:w,dataModelOptions:{name:"cgroup.memory.utilization"},size:{width:"50%",height:"250px"},enableVerticalResize:!1,group:"Container",requireContainerFilter:!0,attrs:{forcey:1,percentage:!0,integer:!1,area:!1}}),C}e.$inject=["MetricDataModel","ConvertedMetricDataModel","CumulativeMetricDataModel","CgroupCPUUsageMetricDataModel","CgroupCPUHeadroomMetricDataModel","CgroupMemoryUsageMetricTimeSeriesDataModel","ContainerMemoryUsageMetricDataModel","ContainerNetworkBytesMetricDataModel","ContainerMultipleMetricDataModel","ContainerMultipleCumulativeMetricDataModel","CgroupMemoryHeadroomMetricDataModel","MemoryUtilizationMetricDataModel","NetworkBytesMetricDataModel","CpuUtilizationMetricDataModel","PerCpuUtilizationMetricDataModel","MultipleMetricDataModel","MultipleCumulativeMetricDataModel","DummyMetricDataModel","DiskLatencyMetricDataModel","CumulativeUtilizationMetricDataModel","CgroupMemoryUtilizationMetricDataModel","config"];var t=[{name:"kernel.all.cpu",size:{width:"50%"}},{name:"kernel.percpu.cpu",size:{width:"50%"}},{name:"kernel.all.runnable",size:{width:"50%"}},{name:"kernel.all.load",size:{width:"50%"}},{name:"network.interface.bytes",size:{width:"50%"}},{name:"network.tcpconn",size:{width:"50%"}},{name:"network.interface.packets",size:{width:"50%"}},{name:"network.tcp.retrans",size:{width:"50%"}},{name:"mem",size:{width:"50%"}},{name:"mem.vmstat.pgfault",size:{width:"50%"}},{name:"kernel.all.pswitch",size:{width:"50%"}},{name:"disk.iops",size:{width:"50%"}},{name:"disk.bytes",size:{width:"50%"}},{name:"disk.dev.avactive",size:{width:"50%"}},{name:"disk.dev.latency",size:{width:"50%"}}],a=[],i=[{name:"cgroup.cpuacct.usage",size:{width:"50%"}},{name:"container.memory.usage",size:{width:"50%"}},{name:"cgroup.memory.usage",size:{width:"50%"}},{name:"cgroup.memory.headroom",size:{width:"50%"}},{name:"container.disk.iops",size:{width:"50%"}},{name:"container.disk.bytes",size:{width:"50%"}}];angular.module("widget",["datamodel","chart","flamegraph","pnamecpuflamegraphtask","uninlinedcpuflamegraphtask","pagefaultflamegraphtask","diskioflamegraphtask","ipcflamegraphtask","cswflamegraphtask","offcpuflamegraphtask","offwakeflamegraphtask","customWidgetSettings","customWidgetHelp"]).factory("widgetDefinitions",e).value("defaultWidgets",t).value("emptyWidgets",a).value("containerWidgets",i)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("uninlinedcpuflamegraphtask",["dashboard"])}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(e,n){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_store?name=vector.task.uninlinedcpuflamegraph&value="+e).success(function(){i.success("vector.task.uninlinedcpuflamegraph requested.","Success"),n("REQUESTED")}).error(function(e){i.error("Failed requesting vector.task.uninlinedcpuflamegraph: "+e,"Error"),n("ERROR "+e)})}function r(e){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_fetch?names=vector.task.uninlinedcpuflamegraph").success(function(t){if(angular.isDefined(t.values[0])){var a=t.values[0].instances[0].value;e(a)}}).error(function(){e("ERROR fetching status")})}return{generate:n,pollStatus:r}}e.$inject=["$log","$rootScope","$http","toastr"],angular.module("uninlinedcpuflamegraphtask").factory("UninlinedCPUFlameGraphService",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(n){n.host=e.properties.host,n.port=e.properties.port,n.context=e.properties.context,n.ready=!1,n.processing=!1,n.id=i.getGuid(),n.svgname="error.svg",n.statusmsg="",n.waited=0,n.pollms=2e3,n.waitedmax=6e5,n.secondoptions=["5","30","60","120"],n.secondselected="60",n.widget.help_url="app/components/uninlinedcpuflamegraphtask/uninlinedcpuflamegraph-help.html",n.pollStatus=function(){a.pollStatus(function(e){n.statusmsg=e,n.waited+=n.pollms;var a=e.split(" ");"DONE"==a[0]||"ERROR"==a[0]||n.waited>n.waitedmax?(n.waited>n.waitedmax&&(n.statusmsg="Error, timed out"),"DONE"==a[0]&&(n.statusmsg="DONE",n.svgname=a[1],n.processing=!1),"ERROR"==a[0]&&(n.ready=!1,n.processing=!1)):t(function(){n.pollStatus()},n.pollms)})},n.generateUninlinedCPUFlameGraph=function(){a.generate(n.secondselected,function(e){var a=e.split(" ");"ERROR"==a[0]?(n.statusmsg=e,n.ready=!1,n.processing=!1):(n.statusmsg=e,n.ready=!0,n.processing=!0,n.waited=0,t(function(){n.pollStatus()},n.pollms))})}}return{restrict:"A",templateUrl:"app/components/uninlinedcpuflamegraphtask/uninlinedcpuflamegraph.html",link:n}}e.$inject=["$rootScope","$timeout","UninlinedCPUFlameGraphService","DashboardService"],angular.module("uninlinedcpuflamegraphtask").directive("uninlinedCpuFlameGraph",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("pnamecpuflamegraphtask",["dashboard"])}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(e,n){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_store?name=vector.task.pnamecpuflamegraph&value="+e).success(function(){i.success("vector.task.pnamecpuflamegraph requested.","Success"),n("REQUESTED")}).error(function(e){i.error("Failed requesting vector.task.pnamecpuflamegraph: "+e,"Error"),n("ERROR "+e)})}function r(e){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_fetch?names=vector.task.pnamecpuflamegraph").success(function(t){if(angular.isDefined(t.values[0])){var a=t.values[0].instances[0].value;e(a)}}).error(function(){e("ERROR fetching status")})}return{generate:n,pollStatus:r}}e.$inject=["$log","$rootScope","$http","toastr"],angular.module("pnamecpuflamegraphtask").factory("PNameCPUFlameGraphService",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(n){n.host=e.properties.host,n.port=e.properties.port,n.context=e.properties.context,n.ready=!1,n.processing=!1,n.id=i.getGuid(),n.svgname="error.svg",n.statusmsg="",n.waited=0,n.pollms=2e3,n.waitedmax=6e5,n.secondoptions=["5","30","60","120"],n.secondselected="60",n.widget.help_url="app/components/pnamecpuflamegraphtask/pnamecpuflamegraph-help.html",n.pollStatus=function(){a.pollStatus(function(e){n.statusmsg=e,n.waited+=n.pollms;var a=e.split(" ");"DONE"==a[0]||"ERROR"==a[0]||n.waited>n.waitedmax?(n.waited>n.waitedmax&&(n.statusmsg="Error, timed out"),"DONE"==a[0]&&(n.statusmsg="DONE",n.svgname=a[1],n.processing=!1),"ERROR"==a[0]&&(n.ready=!1,n.processing=!1)):t(function(){n.pollStatus()},n.pollms)})},n.generatePNameCPUFlameGraph=function(){a.generate(n.secondselected,function(e){var a=e.split(" ");"ERROR"==a[0]?(n.statusmsg=e,n.ready=!1,n.processing=!1):(n.statusmsg=e,n.ready=!0,n.processing=!0,n.waited=0,t(function(){n.pollStatus()},n.pollms))})}}return{restrict:"A",templateUrl:"app/components/pnamecpuflamegraphtask/pnamecpuflamegraph.html",link:n}}e.$inject=["$rootScope","$timeout","PNameCPUFlameGraphService","DashboardService"],angular.module("pnamecpuflamegraphtask").directive("pNameCpuFlameGraph",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(t){var n=a.properties.protocol+"://"+a.properties.host+":"+a.properties.port,r={};return r.method="GET",r.url=n+"/pmapi/context",r.params={},r.params[t.contextType]=t.contextValue,r.params.polltimeout=t.pollTimeout.toString(),r.params.exclusive=1,r.timeout=5e3,e(r).then(function(e){return e.data.context?e.data.context:i.reject("context is undefined")})}function r(e,t){var a={};return a.contextType="hostspec",a.contextValue=e,a.pollTimeout=t,n(a)}function o(e,t){var a={};return a.contextType="hostname",a.contextValue=e,a.pollTimeout=t,n(a)}function s(e){var t={};return t.contextType="local",t.contextValue="ANYTHING",t.pollTimeout=e,n(t)}function l(e,t){var a={};return a.contextType="archivefile",a.contextValue=e,a.pollTimeout=t,n(a)}function c(t,n,r){var o=a.properties.protocol+"://"+a.properties.host+":"+a.properties.port,s={};return s.method="GET",s.url=o+"/pmapi/"+t+"/_fetch",s.params={},angular.isDefined(r)&&null!==r&&r.length>0&&(s.params.pmids=r.join(",")),angular.isDefined(n)&&null!==n&&n.length>0&&(s.params.names=n.join(",")),e(s).then(function(e){return angular.isUndefined(e.data.timestamp)||angular.isUndefined(e.data.timestamp.s)||angular.isUndefined(e.data.timestamp.us)||angular.isUndefined(e.data.values)?i.reject("metric values is empty"):e})}function p(t,n){var r=a.properties.protocol+"://"+a.properties.host+":"+a.properties.port,o={};return o.method="GET",o.url=r+"/pmapi/"+t+"/_store",o.params={name:"pmcd.client.container"},o.params.value=n,e(o).then(function(e){return angular.isUndefined(e.data.success)||1!=e.data.success?i.reject("set container failed"):e})}function d(t,n,r,o){var s=a.properties.protocol+"://"+a.properties.host+":"+a.properties.port,l={};return l.method="GET",l.url=s+"/pmapi/"+t+"/_indom",l.params={indom:n},angular.isDefined(r)&&null!==r&&(l.params.instance=r.join(",")),angular.isDefined(o)&&null!==o&&(l.params.inames=o.join(",")),l.cache=!0,e(l).then(function(e){return angular.isDefined(e.data.indom)||angular.isDefined(e.data.instances)?e:i.reject("instances is undefined")})}function u(t,n,r,o){var s=a.properties.protocol+"://"+a.properties.host+":"+a.properties.port,l={};return l.method="GET",l.url=s+"/pmapi/"+t+"/_indom",l.params={name:n},angular.isDefined(r)&&null!==r&&(l.params.instance=r.join(",")),angular.isDefined(o)&&null!==o&&(l.params.inames=o.join(",")),l.cache=!0,e(l).then(function(e){return angular.isDefined(e.data.instances)?e:i.reject("instances is undefined")})}function h(e){var t=1e3*e.data.timestamp.s+e.data.timestamp.us/1e3,a=e.data.values;return{timestamp:t,values:a}}function m(e){var t={};return angular.forEach(e,function(e){var a=e.data.indom,i=e.config.params.name,n={};angular.forEach(e.data.instances,function(e){n[e.instance.toString()]=e.name}),t[i.toString()]={indom:a,name:i,inames:n}}),t}function g(e,t){var a=i.defer(),n=[];return angular.forEach(t.values,function(t){var a=_.map(t.instances,function(e){return angular.isDefined(e.instance)&&null!==e.instance?e.instance:-1});n.push(u(e,t.name,a))}),i.all(n).then(function(e){var i=m(e),n={timestamp:t.timestamp,values:t.values,inames:i};a.resolve(n)},function(e){a.reject(e)},function(e){a.update(e)}),a.promise}function f(e,t,a){return c(e,t,a).then(h).then(function(t){return g(e,t)})}return{getHostspecContext:r,getHostnameContext:o,getLocalContext:s,getArchiveContext:l,getMetricsValues:c,getMetrics:f,getInstanceDomainsByIndom:d,getInstanceDomainsByName:u,setContainer:p}}angular.module("pmapi",[]).factory("PMAPIService",e),e.$inject=["$http","$log","$rootScope","$q"]}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("pagefaultflamegraphtask",["dashboard"])}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(e,n){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_store?name=vector.task.pagefaultflamegraph&value="+e).success(function(){i.success("vector.task.pagefaultflamegraph requested.","Success"),n("REQUESTED")}).error(function(e){i.error("Failed requesting vector.task.pagefaultflamegraph: "+e,"Error"),n("ERROR "+e)})}function r(e){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_fetch?names=vector.task.pagefaultflamegraph").success(function(t){if(angular.isDefined(t.values[0])){var a=t.values[0].instances[0].value;e(a)}}).error(function(){e("ERROR fetching status")})}return{generate:n,pollStatus:r}}e.$inject=["$log","$rootScope","$http","toastr"],angular.module("pagefaultflamegraphtask").factory("PagefaultFlameGraphService",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(n){n.host=e.properties.host,n.port=e.properties.port,n.context=e.properties.context,n.ready=!1,n.processing=!1,n.id=i.getGuid(),n.svgname="error.svg",n.statusmsg="",n.waited=0,n.pollms=2e3,n.waitedmax=6e5,n.secondoptions=["5","30","60","120"],n.secondselected="60",n.widget.help_url="app/components/pagefaultflamegraphtask/pagefaultflamegraph-help.html",n.pollStatus=function(){a.pollStatus(function(e){n.statusmsg=e,n.waited+=n.pollms;var a=e.split(" ");"DONE"==a[0]||"ERROR"==a[0]||n.waited>n.waitedmax?(n.waited>n.waitedmax&&(n.statusmsg="Error, timed out"),"DONE"==a[0]&&(n.statusmsg="DONE",n.svgname=a[1],n.processing=!1),"ERROR"==a[0]&&(n.ready=!1,n.processing=!1)):t(function(){n.pollStatus()},n.pollms)})},n.generatePagefaultFlameGraph=function(){a.generate(n.secondselected,function(e){var a=e.split(" ");"ERROR"==a[0]?(n.statusmsg=e,n.ready=!1,n.processing=!1):(n.statusmsg=e,n.ready=!0,n.processing=!0,n.waited=0,t(function(){n.pollStatus()},n.pollms))})}}return{restrict:"A",templateUrl:"app/components/pagefaultflamegraphtask/pagefaultflamegraph.html",link:n}}e.$inject=["$rootScope","$timeout","PagefaultFlameGraphService","DashboardService"],angular.module("pagefaultflamegraphtask").directive("pagefaultFlameGraph",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("offwakeflamegraphtask",["dashboard"])}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(e,n){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_store?name=vector.task.offwakeflamegraph&value="+e).success(function(){i.success("vector.task.offwakeflamegraph requested.","Success"),n("REQUESTED")}).error(function(e){i.error("Failed requesting vector.task.offwakeflamegraph: "+e,"Error"),n("ERROR "+e)})}function r(e){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_fetch?names=vector.task.offwakeflamegraph").success(function(t){if(angular.isDefined(t.values[0])){var a=t.values[0].instances[0].value;e(a)}}).error(function(){e("ERROR fetching status")})}return{generate:n,pollStatus:r}}e.$inject=["$log","$rootScope","$http","toastr"],angular.module("offwakeflamegraphtask").factory("OffWakeFlameGraphService",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(n){n.host=e.properties.host,n.port=e.properties.port,n.context=e.properties.context,n.ready=!1,n.processing=!1,n.id=i.getGuid(),n.svgname="error.svg",n.statusmsg="",n.waited=0,n.pollms=2e3,n.waitedmax=6e5,n.secondoptions=["1","5","10","60"],n.secondselected="5",n.widget.help_url="app/components/offwakeflamegraphtask/offwakeflamegraph-help.html",n.pollStatus=function(){a.pollStatus(function(e){n.statusmsg=e,n.waited+=n.pollms;var a=e.split(" ");"DONE"==a[0]||"ERROR"==a[0]||n.waited>n.waitedmax?(n.waited>n.waitedmax&&(n.statusmsg="Error, timed out"),"DONE"==a[0]&&(n.statusmsg="DONE",n.svgname=a[1],n.processing=!1),"ERROR"==a[0]&&(n.ready=!1,n.processing=!1)):t(function(){n.pollStatus()},n.pollms)})},n.generateOffWakeFlameGraph=function(){a.generate(n.secondselected,function(e){var a=e.split(" ");"ERROR"==a[0]?(n.statusmsg=e,n.ready=!1,n.processing=!1):(n.statusmsg=e,n.ready=!0,n.processing=!0,n.waited=0,t(function(){n.pollStatus()},n.pollms))})}}return{restrict:"A",templateUrl:"app/components/offwakeflamegraphtask/offwakeflamegraph.html",link:n}}e.$inject=["$rootScope","$timeout","OffWakeFlameGraphService","DashboardService"],angular.module("offwakeflamegraphtask").directive("offWakeFlameGraph",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("offcpuflamegraphtask",["dashboard"])}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(e,n){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_store?name=vector.task.offcpuflamegraph&value="+e).success(function(){i.success("vector.task.offcpuflamegraph requested.","Success"),n("REQUESTED")}).error(function(e){i.error("Failed requesting vector.task.offcpuflamegraph: "+e,"Error"),n("ERROR "+e)})}function r(e){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_fetch?names=vector.task.offcpuflamegraph").success(function(t){if(angular.isDefined(t.values[0])){var a=t.values[0].instances[0].value;e(a)}}).error(function(){e("ERROR fetching status")})}return{generate:n,pollStatus:r}}e.$inject=["$log","$rootScope","$http","toastr"],angular.module("offcpuflamegraphtask").factory("OffCPUFlameGraphService",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(n){n.host=e.properties.host,n.port=e.properties.port,n.context=e.properties.context,n.ready=!1,n.processing=!1,n.id=i.getGuid(),n.svgname="error.svg",n.statusmsg="",n.waited=0,n.pollms=2e3,n.waitedmax=6e5,n.secondoptions=["1","5","10","60"],n.secondselected="10",n.widget.help_url="app/components/offcpuflamegraphtask/offcpuflamegraph-help.html",n.pollStatus=function(){a.pollStatus(function(e){n.statusmsg=e,n.waited+=n.pollms;var a=e.split(" ");"DONE"==a[0]||"ERROR"==a[0]||n.waited>n.waitedmax?(n.waited>n.waitedmax&&(n.statusmsg="Error, timed out"),"DONE"==a[0]&&(n.statusmsg="DONE",n.svgname=a[1],n.processing=!1),"ERROR"==a[0]&&(n.ready=!1,n.processing=!1)):t(function(){n.pollStatus()},n.pollms)})},n.generateOffCPUFlameGraph=function(){a.generate(n.secondselected,function(e){var a=e.split(" ");"ERROR"==a[0]?(n.statusmsg=e,n.ready=!1,n.processing=!1):(n.statusmsg=e,n.ready=!0,n.processing=!0,n.waited=0,t(function(){n.pollStatus()},n.pollms))})}}return{restrict:"A",templateUrl:"app/components/offcpuflamegraphtask/offcpuflamegraph.html",link:n}}e.$inject=["$rootScope","$timeout","OffCPUFlameGraphService","DashboardService"],angular.module("offcpuflamegraphtask").directive("offCPUFlameGraph",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e){function t(t,n){var r={},o={};return t.backdrop="static",angular.extend(r,a,t),angular.extend(o,i,n),r.controller=["$scope","$uibModalInstance",function(e,t){e.modalOptions=o,e.modalOptions.ok=function(e){t.close(e)},e.modalOptions.close=function(){t.dismiss("cancel")}}],e.open(r).result}var a={backdrop:!0,keyboard:!0,modalFade:!0,template:'<div class="modal-header"><h3>{{modalOptions.headerText}}</h3></div><div class="modal-body"><p>{{modalOptions.bodyText}}</p></div><div class="modal-footer"><button type="button" class="btn" data-ng-click="modalOptions.close()">{{modalOptions.closeButtonText}}</button><button class="btn btn-primary" data-ng-click="modalOptions.ok();">{{modalOptions.actionButtonText}}</button></div>'},i={closeButtonText:"Close",actionButtonText:"OK",headerText:"Proceed?",bodyText:"Perform this action?"};return{showModal:t}}e.$inject=["$uibModal"],angular.module("modal",[]).factory("ModalService",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i,n,r,o,s,l,c){function p(e){var t=_.find(k,function(t){return t.name===e});return angular.isUndefined(t)?(t=new r(e),k.push(t)):t.subscribers++,t}function d(e){var t=_.find(k,function(t){return t.name===e});return angular.isUndefined(t)?(t=new o(e),k.push(t)):t.subscribers++,t}function u(e,t){var a=_.find(k,function(t){return t.name===e});return angular.isUndefined(a)?(a=new s(e,t),k.push(a)):a.subscribers++,a}function h(e,t){var a=_.find(k,function(t){return t.name===e});return angular.isUndefined(a)?(a=new l(e,t),k.push(a)):a.subscribers++,a}function m(e,t){var a=_.find(M,function(t){return t.name===e});return angular.isUndefined(a)?(a=new c(e,t),M.push(a)):a.subscribers++,a}function g(e){var t,a=_.find(k,function(t){return t.name===e});a.subscribers--,a.subscribers<1&&(t=k.indexOf(a),t>-1&&k.splice(t,1))}function f(e){var t,a=_.find(M,function(t){return t.name===e});a.subscribers--,a.subscribers<1&&(t=M.indexOf(a),t>-1&&M.splice(t,1))}function v(){angular.forEach(k,function(e){e.clearData()})}function y(){angular.forEach(M,function(e){e.clearData()})}function b(){return M}function w(){return k}var k=[],M=[];return{getOrCreateMetric:p,getOrCreateCumulativeMetric:d,getOrCreateConvertedMetric:u,getOrCreateCumulativeConvertedMetric:h,getOrCreateDerivedMetric:m,destroyMetric:g,destroyDerivedMetric:f,clearMetricList:v,clearDerivedMetricList:y,getSimpleMetricList:w,getDerivedMetricList:b}}e.$inject=["$rootScope","$http","$log","$q","PMAPIService","SimpleMetric","CumulativeMetric","ConvertedMetric","CumulativeConvertedMetric","DerivedMetric"],angular.module("metriclist",["pmapi","metric"]).factory("MetricListService",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("metric",["pmapi"])}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e){var t=function(e){this.name=e||null,this.data=[],this.subscribers=1,this.pmid=null};return t.prototype.toString=function(){return this.name},t.prototype.pushValue=function(t,a,i,n){var r,o,s=this;r=_.find(s.data,function(e){return e.iid===a}),angular.isDefined(r)&&null!==r?(r.values.push({x:t,y:n}),o=r.values.length-60*parseInt(e.properties.window)/parseInt(e.properties.interval),o>0&&r.values.splice(0,o)):(r={key:angular.isDefined(i)?i:this.name,iid:a,values:[{x:t,y:n},{x:t+1,y:n}]},s.data.push(r))},t.prototype.clearData=function(){this.data.length=0},t.prototype.deleteInvalidInstances=function(e){var t,a,i,n=this;angular.forEach(n.data,function(r){a=_.find(e,function(e){return t=angular.isUndefined(e.instance)?1:e.instance,t===r.iid}),angular.isUndefined(a)&&(i=n.data.indexOf(r),i>-1&&n.data.splice(i,1))})},t}e.$inject=["$rootScope"],angular.module("metric").factory("SimpleMetric",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){return{getInames:function(e,i){return a.getInstanceDomainsByName(t.properties.context,e,[i])}}}e.$inject=["$http","$rootScope","PMAPIService"],angular.module("metric").factory("MetricService",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e){var t=function(e,t){this.name=e,this.data=[],this.subscribers=1,this.derivedFunction=t};return t.prototype.updateValues=function(){var t,a=this;t=a.derivedFunction(),t.length!==a.data.length&&(a.data.length=0),angular.forEach(t,function(t){var i,n=_.find(a.data,function(e){return e.key===t.key});angular.isUndefined(n)?(n={key:t.key,values:[{x:t.timestamp,y:t.value},{x:t.timestamp+1,y:t.value}]},a.data.push(n)):(n.values.push({x:t.timestamp,y:t.value}),i=n.values.length-60*parseInt(e.properties.window)/parseInt(e.properties.interval),i>0&&n.values.splice(0,i))})},t.prototype.clearData=function(){this.data.length=0},t}e.$inject=["$rootScope"],angular.module("metric").factory("DerivedMetric",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(e,t){this.base=i,this.base(e),this.conversionFunction=t};return i.prototype=new a,i.prototype.pushValue=function(t,a,i,n){var r,o,s,l,c=this;r=_.find(c.data,function(e){return e.iid===a}),angular.isUndefined(r)?(r={key:angular.isDefined(i)?i:this.name,iid:a,values:[],previousValue:n,previousTimestamp:t},c.data.push(r)):(s=(n-r.previousValue)/(t-r.previousTimestamp),l=c.conversionFunction(s),r.values.push({x:t,y:l}),r.previousValue=n,r.previousTimestamp=t,o=r.values.length-60*parseInt(e.properties.window)/parseInt(e.properties.interval),o>0&&r.values.splice(0,o))},i}e.$inject=["$rootScope","$log","SimpleMetric"],angular.module("metric").factory("CumulativeConvertedMetric",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(e){this.base=a,this.base(e)};return i.prototype=new a,i.prototype.pushValue=function(t,a,i,n){var r,o,s,l=this;r=_.find(l.data,function(e){return e.iid===a}),angular.isUndefined(r)?(r={key:angular.isDefined(i)?i:this.name,iid:a,values:[],previousValue:n,previousTimestamp:t},l.data.push(r)):(s=(n-r.previousValue)/((t-r.previousTimestamp)/1e3),r.values.length<1?r.values.push({x:t,y:s},{x:t+1,y:s}):r.values.push({x:t,y:s}),r.previousValue=n,r.previousTimestamp=t,o=r.values.length-60*parseInt(e.properties.window)/parseInt(e.properties.interval),o>0&&r.values.splice(0,o))},i}e.$inject=["$rootScope","$log","SimpleMetric"],angular.module("metric").factory("CumulativeMetric",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(e,t){this.base=a,this.base(e),this.conversionFunction=t};return i.prototype=new a,i.prototype.pushValue=function(t,a,i,n){var r,o,s,l=this;s=l.conversionFunction(n),r=_.find(l.data,function(e){return e.iid===a}),angular.isDefined(r)&&null!==r?(r.values.push({x:t,y:s}),o=r.values.length-60*parseInt(e.properties.window)/parseInt(e.properties.interval),o>0&&r.values.splice(0,o)):(r={key:angular.isDefined(i)?i:this.name,iid:a,values:[{x:t,y:s},{x:t+1,y:s}]},l.data.push(r))},i}e.$inject=["$rootScope","$log","SimpleMetric"],angular.module("metric").factory("ConvertedMetric",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("ipcflamegraphtask",["dashboard"])}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(e,n){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_store?name=vector.task.ipcflamegraph&value="+e).success(function(){i.success("vector.task.ipcflamegraph requested.","Success"),n("REQUESTED")}).error(function(e){i.error("Failed requesting vector.task.ipcflamegraph: "+e,"Error"),n("ERROR "+e)})}function r(e){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_fetch?names=vector.task.ipcflamegraph").success(function(t){if(angular.isDefined(t.values[0])){var a=t.values[0].instances[0].value;e(a)}}).error(function(){e("ERROR fetching status")})}return{generate:n,pollStatus:r}}e.$inject=["$log","$rootScope","$http","toastr"],angular.module("ipcflamegraphtask").factory("IPCFlameGraphService",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(n){n.host=e.properties.host,n.port=e.properties.port,n.context=e.properties.context,n.ready=!1,n.processing=!1,n.id=i.getGuid(),n.svgname="error.svg",n.statusmsg="",n.waited=0,n.pollms=2e3,n.waitedmax=6e5,n.secondoptions=["5","30","60","120"],n.secondselected="60",n.widget.help_url="app/components/ipcflamegraphtask/ipcflamegraph-help.html",n.pollStatus=function(){a.pollStatus(function(e){n.statusmsg=e,n.waited+=n.pollms;var a=e.split(" ");"DONE"==a[0]||"ERROR"==a[0]||n.waited>n.waitedmax?(n.waited>n.waitedmax&&(n.statusmsg="Error, timed out"),"DONE"==a[0]&&(n.statusmsg="DONE",n.svgname=a[1],n.processing=!1),"ERROR"==a[0]&&(n.ready=!1,n.processing=!1)):t(function(){n.pollStatus()},n.pollms)})},n.generateIPCFlameGraph=function(){a.generate(n.secondselected,function(e){var a=e.split(" ");"ERROR"==a[0]?(n.statusmsg=e,n.ready=!1,n.processing=!1):(n.statusmsg=e,n.ready=!0,n.processing=!0,n.waited=0,t(function(){n.pollStatus()},n.pollms))})}}return{restrict:"A",templateUrl:"app/components/ipcflamegraphtask/ipcflamegraph.html",link:n}}e.$inject=["$rootScope","$timeout","IPCFlameGraphService","DashboardService"],angular.module("ipcflamegraphtask").directive("ipcFlameGraph",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("flamegraph",["dashboard"])}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(e,n){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_store?name=vector.task.cpuflamegraph&value="+e).success(function(){i.success("vector.task.cpuflamegraph requested.","Success"),n("REQUESTED")}).error(function(e){i.error("Failed requesting vector.task.cpuflamegraph: "+e,"Error"),n("ERROR "+e)})}function r(e){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_fetch?names=vector.task.cpuflamegraph").success(function(t){if(angular.isDefined(t.values[0])){var a=t.values[0].instances[0].value;e(a)}}).error(function(){e("ERROR fetching status")})}return{generate:n,pollStatus:r}}e.$inject=["$log","$rootScope","$http","toastr"],angular.module("flamegraph").factory("FlameGraphService",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(n){n.host=e.properties.host,n.port=e.properties.port,n.context=e.properties.context,n.ready=!1,n.processing=!1,n.id=i.getGuid(),n.svgname="error.svg",n.statusmsg="",n.waited=0,n.pollms=2e3,n.waitedmax=6e5,n.secondoptions=["5","30","60","120"],n.secondselected="60",n.widget.help_url="app/components/flamegraph/flamegraph-help.html",n.pollStatus=function(){a.pollStatus(function(e){n.statusmsg=e,n.waited+=n.pollms;var a=e.split(" ");"DONE"==a[0]||"ERROR"==a[0]||n.waited>n.waitedmax?(n.waited>n.waitedmax&&(n.statusmsg="Error, timed out"),"DONE"==a[0]&&(n.statusmsg="DONE",n.svgname=a[1],n.processing=!1),"ERROR"==a[0]&&(n.ready=!1,n.processing=!1)):t(function(){n.pollStatus()},n.pollms)})},n.generateFlameGraph=function(){a.generate(n.secondselected,function(e){var a=e.split(" ");"ERROR"==a[0]?(n.statusmsg=e,n.ready=!1,n.processing=!1):(n.statusmsg=e,n.ready=!0,n.processing=!0,n.waited=0,t(function(){n.pollStatus()},n.pollms))})}}return{restrict:"A",templateUrl:"app/components/flamegraph/flamegraph.html",link:n}}e.$inject=["$rootScope","$timeout","FlameGraphService","DashboardService"],angular.module("flamegraph").directive("cpuFlameGraph",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("datamodel",["containermetadata","dashboard","metriclist"])}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(){return this};return i.prototype=Object.create(e.prototype),i.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid(),this.metric=t.getOrCreateMetric(this.name),this.updateScope(this.metric.data)},i.prototype.destroy=function(){t.destroyMetric(this.name),e.prototype.destroy.call(this)},i}e.$inject=["WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("MetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(){return this};return i.prototype=Object.create(e.prototype),i.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid();var i,n=t.getOrCreateCumulativeMetric("kernel.percpu.cpu.sys"),r=t.getOrCreateCumulativeMetric("kernel.percpu.cpu.user");i=function(){var e,t,a,i=[];return angular.forEach(n.data,function(n){n.values.length>0&&(e=_.find(r.data,function(e){return e.key===n.key}),angular.isDefined(e)&&(t=n.values[n.values.length-1],a=e.values[e.values.length-1],t.x===a.x&&i.push({timestamp:t.x,key:n.key,value:(t.y+a.y)/1e3})))}),i},this.metric=t.getOrCreateDerivedMetric(this.name,i),this.updateScope(this.metric.data)},i.prototype.destroy=function(){t.destroyDerivedMetric(this.name),t.destroyMetric("kernel.percpu.cpu.sys"),t.destroyMetric("kernel.percpu.cpu.user"),e.prototype.destroy.call(this)},i}e.$inject=["WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("PerCpuUtilizationMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(){return this};return i.prototype=Object.create(e.prototype),i.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid();var i,n=this,r=t.getOrCreateCumulativeMetric("network.interface.in.bytes"),o=t.getOrCreateCumulativeMetric("network.interface.out.bytes");i=function(){var e,t=[],a=function(a,i){a.values.length>0&&-1!==a.key.indexOf(n.widgetScope.widget.filter)&&(e=a.values[a.values.length-1],t.push({timestamp:e.x,key:a.key+i,value:e.y/1024}))};return angular.forEach(r.data,function(e){a(e," in")}),angular.forEach(o.data,function(e){a(e," out")}),t},this.metric=t.getOrCreateDerivedMetric(this.name,i),this.updateScope(this.metric.data)},i.prototype.destroy=function(){t.destroyDerivedMetric(this.name),t.destroyMetric("network.interface.in.bytes"),t.destroyMetric("network.interface.out.bytes"),e.prototype.destroy.call(this)},i}e.$inject=["WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("NetworkBytesMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(){return this};return i.prototype=Object.create(e.prototype),i.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid(),this.metricDefinitions=this.dataModelOptions.metricDefinitions;var i,n={};angular.forEach(this.metricDefinitions,function(e,a){n[a]=t.getOrCreateMetric(e)}),i=function(){var e,t=[];return angular.forEach(n,function(a,i){angular.forEach(a.data,function(a){a.values.length>0&&(e=a.values[a.values.length-1],t.push({timestamp:e.x,key:i.replace("{key}",a.key),value:e.y}))})}),t},this.metric=t.getOrCreateDerivedMetric(this.name,i),this.updateScope(this.metric.data)},i.prototype.destroy=function(){t.destroyDerivedMetric(this.name),angular.forEach(this.metricDefinitions,function(e){t.destroyMetric(e)}),e.prototype.destroy.call(this)},i}e.$inject=["WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("MultipleMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(){return this};return i.prototype=Object.create(e.prototype),i.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid(),this.metricDefinitions=this.dataModelOptions.metricDefinitions;var i,n=this,r={};angular.forEach(this.metricDefinitions,function(e,a){r[a]=t.getOrCreateCumulativeMetric(e)}),i=function(){var e,t=[];return angular.forEach(r,function(a,i){angular.forEach(a.data,function(a){a.values.length>0&&(angular.isUndefined(n.widgetScope.widget.filter)||-1!==a.key.indexOf(n.widgetScope.widget.filter))&&(e=a.values[a.values.length-1],t.push({timestamp:e.x,key:i.replace("{key}",a.key),value:e.y}))})}),t},this.metric=t.getOrCreateDerivedMetric(this.name,i),this.updateScope(this.metric.data)},i.prototype.destroy=function(){t.destroyDerivedMetric(this.name),angular.forEach(this.metricDefinitions,function(e){t.destroyMetric(e)}),e.prototype.destroy.call(this)},i}e.$inject=["WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("MultipleCumulativeMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(){return this};return i.prototype=Object.create(e.prototype),i.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid();var i,n=function(e){return e/1024},r=t.getOrCreateConvertedMetric("mem.util.cached",n),o=t.getOrCreateConvertedMetric("mem.util.used",n),s=t.getOrCreateConvertedMetric("mem.util.free",n),l=t.getOrCreateConvertedMetric("mem.util.bufmem",n);i=function(){var e,t,a,i,n=[];return e=function(){if(o.data.length>0){var e=o.data[o.data.length-1];if(e.values.length>0)return e.values[e.values.length-1]}}(),t=function(){if(r.data.length>0){var e=r.data[r.data.length-1];if(e.values.length>0)return e.values[e.values.length-1]}}(),a=function(){if(s.data.length>0){var e=s.data[s.data.length-1];if(e.values.length>0)return e.values[e.values.length-1]}}(),i=function(){if(l.data.length>0){var e=l.data[l.data.length-1];if(e.values.length>0)return e.values[e.values.length-1]}}(),angular.isDefined(e)&&angular.isDefined(t)&&angular.isDefined(i)&&n.push({timestamp:e.x,key:"application",value:e.y-t.y-i.y}),angular.isDefined(t)&&angular.isDefined(i)&&n.push({timestamp:e.x,key:"free (cache)",value:t.y+i.y}),angular.isDefined(a)&&n.push({timestamp:e.x,key:"free (unused)",value:a.y}),n},this.metric=t.getOrCreateDerivedMetric(this.name,i),this.updateScope(this.metric.data)},i.prototype.destroy=function(){t.destroyDerivedMetric(this.name),t.destroyMetric("mem.util.cached"),t.destroyMetric("mem.util.used"),t.destroyMetric("mem.util.free"),t.destroyMetric("mem.util.bufmem"),e.prototype.destroy.call(this)},i}e.$inject=["WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("MemoryUtilizationMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t){var a=function(){return this};return a.prototype=Object.create(e.prototype),a.prototype.init=function(){e.prototype.init.call(this),this.metric=t.getOrCreateMetric("kernel.uname.release")},a.prototype.destroy=function(){t.destroyMetric("kernel.uname.release"),e.prototype.destroy.call(this)},a}e.$inject=["WidgetDataModel","MetricListService"],angular.module("datamodel").factory("DummyMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(){return this};return i.prototype=Object.create(e.prototype),i.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid();var i,n=t.getOrCreateCumulativeMetric("disk.dev.read_rawactive"),r=t.getOrCreateCumulativeMetric("disk.dev.write_rawactive"),o=t.getOrCreateCumulativeMetric("disk.dev.read"),s=t.getOrCreateCumulativeMetric("disk.dev.write");i=function(){function e(e,n,r,o){e.data.length>0&&angular.forEach(e.data,function(e){t=_.find(n.data,function(t){return t.key===e.key}),angular.isDefined(t)&&e.values.length>0&&t.values.length>0&&(a=e.values[e.values.length-1],i=t.values[e.values.length-1],l=a.y>0?i.y/a.y:0,o.push({timestamp:a.x,key:e.key+r,value:l}))})}var t,a,i,l,c=[];return e(o,n," read latency",c),e(s,r," write latency",c),c},this.metric=t.getOrCreateDerivedMetric(this.name,i),this.updateScope(this.metric.data)},i.prototype.destroy=function(){t.destroyDerivedMetric(this.name),t.destroyMetric("disk.dev.read_rawactive"),t.destroyMetric("disk.dev.write_rawactive"),t.destroyMetric("disk.dev.read"),t.destroyMetric("disk.dev.write"),e.prototype.destroy.call(this)},i}e.$inject=["WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("DiskLatencyMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(){return this};return i.prototype=Object.create(e.prototype),i.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid();var i,n=t.getOrCreateCumulativeMetric(this.name);i=function(){var e,t=[];return angular.forEach(n.data,function(a){a.values.length>0&&(e=a.values[a.values.length-1],t.push({timestamp:e.x,key:a.key,value:e.y/1e3}))}),t},this.metric=t.getOrCreateDerivedMetric(this.name,i),this.updateScope(this.metric.data)},i.prototype.destroy=function(){t.destroyDerivedMetric(this.name),t.destroyMetric(this.name),e.prototype.destroy.call(this)},i}e.$inject=["WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("CumulativeUtilizationMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(){return this};return i.prototype=Object.create(e.prototype),i.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid(),this.metric=t.getOrCreateCumulativeMetric(this.name),this.updateScope(this.metric.data)},i.prototype.destroy=function(){t.destroyMetric(this.name),e.prototype.destroy.call(this)},i}e.$inject=["WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("CumulativeMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(){return this};return i.prototype=Object.create(e.prototype),i.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid();var i,n=t.getOrCreateCumulativeMetric("kernel.all.cpu.sys"),r=t.getOrCreateCumulativeMetric("kernel.all.cpu.user"),o=t.getOrCreateMetric("hinv.ncpu");i=function(){var e,t,a=[];if(o.data.length>0&&(e=o.data[o.data.length-1],e.values.length>0)){t=e.values[e.values.length-1].y;var i=function(e,i){if(e.values.length>0){var n=e.values[e.values.length-1];a.push({timestamp:n.x,key:i,value:n.y/(1e3*t)})}};angular.forEach(n.data,function(e){i(e,"sys")}),angular.forEach(r.data,function(e){i(e,"user")})}return a},this.metric=t.getOrCreateDerivedMetric(this.name,i),this.updateScope(this.metric.data)},i.prototype.destroy=function(){t.destroyDerivedMetric(this.name),t.destroyMetric("kernel.all.cpu.sys"),t.destroyMetric("kernel.all.cpu.user"),t.destroyMetric("hinv.ncpu"),e.prototype.destroy.call(this)},i}e.$inject=["WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("CpuUtilizationMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(){return this};return i.prototype=Object.create(e.prototype),i.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid(),this.conversionFunction=this.dataModelOptions.conversionFunction,this.metric=t.getOrCreateConvertedMetric(this.name,this.conversionFunction),this.updateScope(this.metric.data)},i.prototype.destroy=function(){t.destroyMetric(this.name),e.prototype.destroy.call(this)},i}e.$inject=["WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("ConvertedMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){var i=function(){return this};return i.prototype=Object.create(e.prototype),i.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid();var i,n=this,r=t.getOrCreateCumulativeMetric("network.interface.in.bytes"),o=t.getOrCreateCumulativeMetric("network.interface.out.bytes");i=function(){var e,t=[];return angular.forEach(r.data,function(a){a.values.length>0&&-1!==a.key.indexOf("veth")&&-1!==a.key.indexOf(n.widgetScope.widget.filter)&&(e=a.values[a.values.length-1],t.push({timestamp:e.x,key:a.key+" in",value:e.y/1024}))}),angular.forEach(o.data,function(a){a.values.length>0&&-1!==a.key.indexOf("veth")&&-1!==a.key.indexOf(n.widgetScope.widget.filter)&&(e=a.values[a.values.length-1],t.push({timestamp:e.x,key:a.key+" out",value:e.y/1024}))}),t},this.metric=t.getOrCreateDerivedMetric("container.network.interface",i),this.updateScope(this.metric.data)},i.prototype.destroy=function(){t.destroyDerivedMetric("container.network.interface"),t.destroyMetric("network.interface.in.bytes"),t.destroyMetric("network.interface.out.bytes"),e.prototype.destroy.call(this)},i}e.$inject=["WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("ContainerNetworkBytesMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){var n=function(){return this};return n.prototype=Object.create(e.prototype),n.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid(),this.metricDefinitions=this.dataModelOptions.metricDefinitions;var n,r={};angular.forEach(this.metricDefinitions,function(e,a){r[a]=t.getOrCreateMetric(e)}),n=function(){var e,t,a=[];return angular.forEach(r,function(n,r){angular.forEach(n.data,function(n){i.containerIdExist(n.key)&&(t=i.idDictionary(n.key)||n.key,n.values.length>0&&i.checkContainerName(t)&&i.checkContainerFilter(t)&&(e=n.values[n.values.length-1],a.push({timestamp:e.x,key:r.replace("{key}",t),value:e.y})))})}),a},this.metric=t.getOrCreateDerivedMetric(this.name,n),this.updateScope(this.metric.data)},n.prototype.destroy=function(){t.destroyDerivedMetric(this.name),angular.forEach(this.metricDefinitions,function(e){t.destroyMetric(e)}),e.prototype.destroy.call(this)},n}e.$inject=["WidgetDataModel","MetricListService","DashboardService","ContainerMetadataService"],angular.module("datamodel").factory("ContainerMultipleMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){var n=function(){return this};return n.prototype=Object.create(e.prototype),n.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid(),this.metricDefinitions=this.dataModelOptions.metricDefinitions;var n,r={};angular.forEach(this.metricDefinitions,function(e,a){r[a]=t.getOrCreateCumulativeMetric(e)}),n=function(){var e,t,a=[];return angular.forEach(r,function(n,r){angular.forEach(n.data,function(n){i.containerIdExist(n.key)&&(t=i.idDictionary(n.key)||n.key,n.values.length>0&&i.checkContainerName(t)&&i.checkContainerFilter(t)&&(e=n.values[n.values.length-1],a.push({timestamp:e.x,key:r.replace("{key}",t),value:e.y})))})}),a},this.metric=t.getOrCreateDerivedMetric(this.name,n),this.updateScope(this.metric.data)},n.prototype.destroy=function(){t.destroyDerivedMetric(this.name),angular.forEach(this.metricDefinitions,function(e){t.destroyMetric(e)}),e.prototype.destroy.call(this)},n}e.$inject=["WidgetDataModel","MetricListService","DashboardService","ContainerMetadataService"],angular.module("datamodel").factory("ContainerMultipleCumulativeMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){var n=function(){return this};return n.prototype=Object.create(e.prototype),n.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid();var n,r=function(e){return e/1024/1024},o=function(e){return e/1024},s=t.getOrCreateConvertedMetric("mem.util.used",o),l=t.getOrCreateConvertedMetric("mem.util.free",o),c=t.getOrCreateConvertedMetric("cgroup.memory.usage",r);n=function(){var e,t,a,n=[];return e=function(){if(s.data.length>0){var e=s.data[s.data.length-1];if(e.values.length>0)return e.values[e.values.length-1]}}(),t=function(){if(l.data.length>0){var e=l.data[l.data.length-1];if(e.values.length>0)return e.values[e.values.length-1]}}(),a=function(){if(c.data.length>0){var e=0,t=c.data[c.data.length-1].values[c.data[c.data.length-1].values.length-1].x;return angular.forEach(c.data,function(t){t.values.length>0&&i.containerIdExist(t.key)&&(e+=t.values[t.values.length-1].y)}),{x:t,y:e}}}(),angular.isDefined(e)&&angular.isDefined(a)&&n.push({timestamp:e.x,key:"host used",value:e.y-a.y}),angular.isDefined(t)&&n.push({timestamp:t.x,key:"free (unused)",value:t.y}),angular.isDefined(a)&&angular.isDefined(e)&&n.push({timestamp:a.x,key:"container used",value:a.y}),n},this.metric=t.getOrCreateDerivedMetric(this.name,n),this.updateScope(this.metric.data)},n.prototype.destroy=function(){t.destroyDerivedMetric(this.name),t.destroyMetric("mem.util.used"),t.destroyMetric("mem.util.free"),t.destroyMetric("cgroup.memory.usage"),e.prototype.destroy.call(this)},n}e.$inject=["WidgetDataModel","MetricListService","DashboardService","ContainerMetadataService"],angular.module("datamodel").factory("ContainerMemoryUsageMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){var n=function(){return this};return n.prototype=Object.create(e.prototype),n.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid();var n,r=function(e){return e/1024/1024},o=function(e){return e/1024},s=t.getOrCreateConvertedMetric("cgroup.memory.usage",r),l=t.getOrCreateConvertedMetric("cgroup.memory.limit",r),c=t.getOrCreateConvertedMetric("mem.physmem",o);n=function(){var e,t=[];return e=function(){if(c.data.length>0){var e=c.data[c.data.length-1];if(e.values.length>0)return e.values[e.values.length-1]}}(),angular.forEach(s.data,function(a){if(a.values.length>0&&i.containerIdExist(a.key)){var n=a.values[a.values.length-1],r=i.idDictionary(a.key)||a.key;if(i.checkContainerName(r)&&i.checkContainerFilter(r)){var o=_.find(l.data,function(e){return e.key===a.key});if(angular.isDefined(o)){var s=o.values[o.values.length-1];s.y>=e.y?t.push({timestamp:n.x,key:r,value:n.y/e.y}):t.push({timestamp:n.x,key:r,value:n.y/s.y})}}}}),t},this.metric=t.getOrCreateDerivedMetric(this.name,n),this.updateScope(this.metric.data)},n.prototype.destroy=function(){t.destroyDerivedMetric(this.name),t.destroyMetric("cgroup.memory.usage"),t.destroyMetric("cgroup.memory.limit"),t.destroyMetric("mem.physmem"),e.prototype.destroy.call(this)},n}e.$inject=["WidgetDataModel","MetricListService","DashboardService","ContainerMetadataService"],angular.module("datamodel").factory("CgroupMemoryUtilizationMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){var n=function(){return this};return n.prototype=Object.create(t.prototype),n.prototype.init=function(){t.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+i.getGuid();var n,r=function(e){return e/1024/1024},o=a.getOrCreateConvertedMetric("cgroup.memory.usage",r);n=function(){var t,a,i=[];return angular.forEach(o.data,function(n){n.values.length>0&&e.containerIdExist(n.key)&&(t=n.values[n.values.length-1],a=e.idDictionary(n.key)||n.key,e.checkContainerName(a)&&e.checkContainerFilter(a)&&i.push({timestamp:t.x,key:a,value:t.y}))}),i},this.metric=a.getOrCreateDerivedMetric(this.name,n),this.updateScope(this.metric.data)},n.prototype.destroy=function(){a.destroyDerivedMetric(this.name),a.destroyMetric("cgroup.memory.usage"),t.prototype.destroy.call(this)},n}e.$inject=["ContainerMetadataService","WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("CgroupMemoryUsageMetricTimeSeriesDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){var n=function(){return this};return n.prototype=Object.create(e.prototype),n.prototype.init=function(){e.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+a.getGuid();var n,r=function(e){return e/1024/1024},o=function(e){return e/1024},s=t.getOrCreateConvertedMetric("cgroup.memory.usage",r),l=t.getOrCreateConvertedMetric("cgroup.memory.limit",r),c=t.getOrCreateConvertedMetric("mem.physmem",o);n=function(){var e,t=[];return e=function(){if(c.data.length>0){var e=c.data[c.data.length-1];if(e.values.length>0)return e.values[e.values.length-1]}}(),angular.forEach(s.data,function(e){if(e.values.length>0&&i.containerIdExist(e.key)){var a=e.values[e.values.length-1],n=i.idDictionary(e.key)||e.key;i.checkContainerName(n)&&i.checkContainerFilter(n)&&t.push({timestamp:a.x,key:n+" used",value:a.y})}}),angular.forEach(l.data,function(a){if(a.values.length>0&&i.containerIdExist(a.key)){var n=a.values[a.values.length-1],r=i.idDictionary(a.key)||a.key;i.checkContainerName(r)&&i.checkContainerFilter(r)&&(n.y>=e.y?t.push({timestamp:e.x,key:r+" limit (physical)",value:e.y}):t.push({timestamp:n.x,key:r+" limit",value:n.y}))}}),t},this.metric=t.getOrCreateDerivedMetric(this.name,n),this.updateScope(this.metric.data)},n.prototype.destroy=function(){t.destroyDerivedMetric(this.name),t.destroyMetric("cgroup.memory.usage"),t.destroyMetric("cgroup.memory.limit"),t.destroyMetric("mem.physmem"),e.prototype.destroy.call(this)},n}e.$inject=["WidgetDataModel","MetricListService","DashboardService","ContainerMetadataService"],angular.module("datamodel").factory("CgroupMemoryHeadroomMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){var n=function(){return this};return n.prototype=Object.create(t.prototype),n.prototype.init=function(){t.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+i.getGuid();var n,r=a.getOrCreateCumulativeMetric("cgroup.cpuacct.usage");n=function(){var t,a,i=[];return r.data.length>0&&angular.forEach(r.data,function(n){n.values.length>0&&e.containerIdExist(n.key)&&(t=n.values[n.values.length-1],a=e.idDictionary(n.key)||n.key,e.checkContainerName(a)&&e.checkContainerFilter(a)&&i.push({timestamp:t.x,key:a,value:t.y/1e3/1e3/1e3}))}),i},this.metric=a.getOrCreateDerivedMetric(this.name,n),this.updateScope(this.metric.data)},n.prototype.destroy=function(){a.destroyDerivedMetric(this.name),a.destroyMetric("cgroup.cpuacct.usage"),t.prototype.destroy.call(this)},n}e.$inject=["ContainerMetadataService","WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("CgroupCPUUsageMetricDataModel",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){var n=function(){return this};return n.prototype=Object.create(t.prototype),n.prototype.init=function(){t.prototype.init.call(this),this.name=this.dataModelOptions?this.dataModelOptions.name:"metric_"+i.getGuid();var n,r=a.getOrCreateCumulativeMetric("cgroup.cpuacct.usage"),o=a.getOrCreateMetric("cgroup.cpusched.shares"),s=a.getOrCreateMetric("cgroup.cpusched.periods"),l=a.getOrCreateMetric("hinv.ncpu");n=function(){var t=[];return r.data.length>0&&angular.forEach(r.data,function(a){if(a.values.length>0&&e.containerIdExist(a.key)){var i=a.values[a.values.length-1],n=e.idDictionary(a.key)||a.key;e.checkContainerName(n)&&e.checkContainerFilter(n)&&t.push({timestamp:i.x,key:n,value:i.y/1e3/1e3/1e3})}}),s.data.length>0&&angular.forEach(s.data,function(a){if(a.values.length>0&&e.containerIdExist(a.key)){var i=a.values[a.values.length-1],n=e.idDictionary(a.key)||a.key;if(e.checkContainerName(n)&&e.checkContainerFilter(n))if(i.y>0){var r=_.find(o.data,function(e){return e.key===a.key});if(angular.isDefined(r)){var s=r.values[r.values.length-1];t.push({timestamp:i.x,key:n+" (limit)",value:s.y/i.y})}}else if(l.data.length>0){var c=l.data[l.data.length-1];if(c.values.length>0){var p=c.values[c.values.length-1];t.push({timestamp:p.x,key:n+" (physical)",value:p.y})}}}}),t},this.metric=a.getOrCreateDerivedMetric(this.name,n),this.updateScope(this.metric.data)},n.prototype.destroy=function(){a.destroyDerivedMetric(this.name),a.destroyMetric("cgroup.cpuacct.usage"),t.prototype.destroy.call(this)},n}e.$inject=["ContainerMetadataService","WidgetDataModel","MetricListService","DashboardService"],angular.module("datamodel").factory("CgroupCPUHeadroomMetricDataModel",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("diskioflamegraphtask",["dashboard"])}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(e,n){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_store?name=vector.task.diskioflamegraph&value="+e).success(function(){i.success("vector.task.diskioflamegraph requested.","Success"),n("REQUESTED")}).error(function(e){i.error("Failed requesting vector.task.diskioflamegraph: "+e,"Error"),n("ERROR "+e)})}function r(e){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_fetch?names=vector.task.diskioflamegraph").success(function(t){if(angular.isDefined(t.values[0])){var a=t.values[0].instances[0].value;e(a)}}).error(function(){e("ERROR fetching status")})}return{generate:n,pollStatus:r}}e.$inject=["$log","$rootScope","$http","toastr"],angular.module("diskioflamegraphtask").factory("DiskIOFlameGraphService",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(n){n.host=e.properties.host,n.port=e.properties.port,n.context=e.properties.context,n.ready=!1,n.processing=!1,n.id=i.getGuid(),n.svgname="error.svg",n.statusmsg="",n.waited=0,n.pollms=2e3,n.waitedmax=6e5,n.secondoptions=["5","30","60","120"],n.secondselected="60",n.widget.help_url="app/components/diskioflamegraphtask/diskioflamegraph-help.html",n.pollStatus=function(){a.pollStatus(function(e){n.statusmsg=e,n.waited+=n.pollms;var a=e.split(" ");"DONE"==a[0]||"ERROR"==a[0]||n.waited>n.waitedmax?(n.waited>n.waitedmax&&(n.statusmsg="Error, timed out"),"DONE"==a[0]&&(n.statusmsg="DONE",n.svgname=a[1],n.processing=!1),"ERROR"==a[0]&&(n.ready=!1,n.processing=!1)):t(function(){n.pollStatus()},n.pollms)})},n.generateDiskIOFlameGraph=function(){a.generate(n.secondselected,function(e){var a=e.split(" ");"ERROR"==a[0]?(n.statusmsg=e,n.ready=!1,n.processing=!1):(n.statusmsg=e,n.ready=!0,n.processing=!0,n.waited=0,t(function(){n.pollStatus()},n.pollms))})}}return{restrict:"A",templateUrl:"app/components/diskioflamegraphtask/diskioflamegraph.html",link:n}}e.$inject=["$rootScope","$timeout","DiskIOFlameGraphService","DashboardService"],angular.module("diskioflamegraphtask").directive("diskioFlameGraph",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i,n,r,o,s,l,c){function p(){k&&a.cancel(k)}function d(t){t?M=0:(r.error("Failed fetching metrics. Trying again.","Error"),M+=1),M>5&&(p(k),M=0,e.properties.context="-1",e.flags.contextAvailable=!1,r.error("Consistently failed fetching metrics from host (>5). Please update the hostname to resume operation.","Error"))}function u(t){var a=[],i=[],n=e.properties.context,r=l.getSimpleMetricList();n&&n>0&&r.length>0&&(angular.forEach(r,function(e){angular.isDefined(e.pmid)&&null!==e.pmid?i.push(e.pmid):a.push(e.name)}),s.getMetrics(n,a,i).then(function(e){var t,a,i,n;if(e.values.length!==r.length){var o;angular.forEach(r,function(t){o=_.find(e.values,function(e){return e.name===t.name}),angular.isUndefined(o)&&t.clearData()})}angular.forEach(e.values,function(o){t=o.name,a=_.find(r,function(e){return e.name===t}),o.instances.length!==a.data.length&&a.deleteInvalidInstances(o.instances),angular.isDefined(a)&&null!==a&&(angular.isNumber(a.pmid)||(a.pmid=o.pmid),angular.forEach(o.instances,function(r){i=angular.isUndefined(r.instance)?1:r.instance,n=e.inames[t].inames[i],a.pushValue(e.timestamp,i,n,r.value)}))})}).then(function(){t(!0),e.$broadcast("updateMetrics")},function(e){400===e.status&&-1!==e.data.indexOf("-12376")&&v(),t(!1)}))}function h(){var t=l.getDerivedMetricList();t.length>0&&(angular.forEach(t,function(e){e.updateValues()}),e.$broadcast("updateDerivedMetrics"))}function m(){u(d),h()}function g(){p(k),e.properties.host&&(e.properties.context&&e.properties.context>0?k=a(m,1e3*parseInt(e.properties.interval)):r.error("Vector is not connected to the host. Please update the hostname to resume operation.","Error"))}function f(t){var a=null;t&&(a=t.match("(.*):([0-9]*)"),null!==a?(e.properties.host=a[1],e.properties.port=a[2]):e.properties.host=t)}function v(){e.flags.contextUpdating=!0,e.flags.contextAvailable=!1,s.getHostspecContext(e.properties.hostspec,600).then(function(t){e.flags.contextUpdating=!1,e.flags.contextAvailable=!0,e.properties.context=t,g(),s.getMetrics(t,["pmcd.hostname"]).then(function(t){e.properties.hostname=t.values[0].instances[0].value},function(){e.properties.hostname="Hostname not available.",i.error("Error fetching hostname.")})},function(){r.error("Failed fetching context from host. Try updating the hostname.","Error"),e.flags.contextUpdating=!1,e.flags.contextAvailable=!1})}function y(t){n.search("host",t),n.search("hostspec",e.properties.hostspec),e.properties.context=-1,e.properties.hostname=null,e.properties.port=o.port,l.clearMetricList(),l.clearDerivedMetricList(),f(t),v()}function b(){e.properties?(e.properties.interval||(e.properties.interval=o.interval),e.properties.window||(e.properties.window=o.window),e.properties.protocol||(e.properties.protocol=o.protocol),e.properties.host||(e.properties.host=""),e.properties.hostspec||(e.properties.hostspec=o.hostspec),e.properties.port||(e.properties.port=o.port),!e.properties.context||e.properties.context<0?v():g()):e.properties={protocol:o.protocol,host:"",hostspec:o.hostspec,port:o.port,context:-1,hostname:null,window:o.window,interval:o.interval,containerFilter:"",containerList:[],selectedContainer:""},e.flags={contextAvailable:!1,contextUpdating:!1,isHostnameExpanded:o.expandHostname,enableContainerWidgets:o.enableContainerWidgets,disableHostspecInput:o.disableHostspecInput,disableContainerFilter:o.disableContainerFilter,disableContainerSelect:o.disableContainerSelect,containerSelectOverride:o.containerSelectOverride,disableContainerSelectNone:!1,disableHostnameInputContainerSelect:o.disableHostnameInputContainerSelect},o.enableContainerWidgets&&c.initialize()}function w(){return Math.floor(65536*(1+Math.random())).toString(16).substring(1)}var k,M=0;return{cancelInterval:p,updateInterval:g,updateHost:y,updateContext:v,getGuid:w,initialize:b}}e.$inject=["$rootScope","$http","$interval","$log","$location","toastr","config","PMAPIService","MetricListService","ContainerMetadataService"],angular.module("dashboard",["pmapi","metriclist","containermetadata"]).factory("DashboardService",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(){function e(){return function(e){return d3.time.format("%X")(new Date(e))}}function t(){return function(e){return d3.format(".02f")(e)}}function a(){return function(e){return d3.format("f")(e)}}function i(){return function(e){return d3.format("%")(e)}}function n(){return function(e){return e.x}}function r(){return function(e){return e.y}}function o(){return"chart_"+Math.floor(65536*(1+Math.random())).toString(16).substring(1)}return{xAxisTickFormat:e,yAxisTickFormat:t,yAxisIntegerTickFormat:a,yAxisPercentageTickFormat:i,xFunction:n,yFunction:r,getId:o}}angular.module("d3",[]).factory("D3Service",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){e.widget=a,e.result=angular.extend({},e.result,a),e.ok=function(){t.close(e.result)},e.cancel=function(){t.dismiss("cancel")}}e.$inject=["$scope","$uibModalInstance","widget"],angular.module("customWidgetSettings",[]).controller("CustomWidgetSettingsController",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("cswflamegraphtask",["dashboard"])}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(e,n){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_store?name=vector.task.cswflamegraph&value="+e).success(function(){i.success("vector.task.cswflamegraph requested.","Success"),n("REQUESTED")}).error(function(e){i.error("Failed requesting vector.task.cswflamegraph: "+e,"Error"),n("ERROR "+e)})}function r(e){a.get(t.properties.protocol+"://"+t.properties.host+":"+t.properties.port+"/pmapi/"+t.properties.context+"/_fetch?names=vector.task.cswflamegraph").success(function(t){if(angular.isDefined(t.values[0])){var a=t.values[0].instances[0].value;e(a)}}).error(function(){e("ERROR fetching status")})}return{generate:n,pollStatus:r}}e.$inject=["$log","$rootScope","$http","toastr"],angular.module("cswflamegraphtask").factory("CSwFlameGraphService",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i){function n(n){n.host=e.properties.host,n.port=e.properties.port,n.context=e.properties.context,n.ready=!1,n.processing=!1,n.id=i.getGuid(),n.svgname="error.svg",n.statusmsg="",n.waited=0,n.pollms=2e3,n.waitedmax=6e5,n.secondoptions=["1","5","10","60"],n.secondselected="10",n.widget.help_url="app/components/cswflamegraphtask/cswflamegraph-help.html",n.pollStatus=function(){a.pollStatus(function(e){n.statusmsg=e,n.waited+=n.pollms;var a=e.split(" ");"DONE"==a[0]||"ERROR"==a[0]||n.waited>n.waitedmax?(n.waited>n.waitedmax&&(n.statusmsg="Error, timed out"),"DONE"==a[0]&&(n.statusmsg="DONE",n.svgname=a[1],n.processing=!1),"ERROR"==a[0]&&(n.ready=!1,n.processing=!1)):t(function(){n.pollStatus()},n.pollms)})},n.generateCSwFlameGraph=function(){a.generate(n.secondselected,function(e){var a=e.split(" ");"ERROR"==a[0]?(n.statusmsg=e,n.ready=!1,n.processing=!1):(n.statusmsg=e,n.ready=!0,n.processing=!0,n.waited=0,t(function(){n.pollStatus()},n.pollms))})}}return{restrict:"A",templateUrl:"app/components/cswflamegraphtask/cswflamegraph.html",link:n}}e.$inject=["$rootScope","$timeout","CSwFlameGraphService","DashboardService"],angular.module("cswflamegraphtask").directive("cswFlameGraph",e)}(),/**!
 *
 *  Copyright 2017 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){e.widget=a,e.result=angular.extend({},e.result,a),e.ok=function(){t.close(e.result)},e.cancel=function(){t.dismiss("cancel")}}e.$inject=["$scope","$uibModalInstance","widget"],angular.module("customWidgetHelp",[]).controller("CustomWidgetHelpController",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
nv.models.tooltip=function(){"use strict";function e(){if(!d){var e=document.body;d=d3.select(e).append("div").attr("class","nvtooltip "+(s?s:"xy-tooltip")).attr("id",a),d.style("top",0).style("left",0),d.style("opacity",0),d.style("position","fixed"),d.selectAll("div, table, td, tr").classed(f,!0),d.classed(f,!0)}}function t(){return h&&M(i)?(nv.dom.write(function(){e();var t=k(i);t&&(d.node().innerHTML=t),x()}),t):void 0}var a="nvtooltip-"+Math.floor(1e5*Math.random()),i=null,n="w",r=25,o=0,s=null,l=null,c=!0,p=200,d=null,u={left:null,top:null},h=!0,m=100,g=!0,f="nv-pointer-events-none",v=function(){return{left:d3.event.clientX,top:d3.event.clientY}},y=function(e){return e},b=function(e){return e},w=function(e){return e},k=function(e){if(null===e)return"";var t=d3.select(document.createElement("table"));if(g){var a=t.selectAll("thead").data([e]).enter().append("thead");a.append("tr").append("td").attr("colspan",3).append("strong").classed("x-value",!0).html(b(e.value))}var i=t.selectAll("tbody").data([e]).enter().append("tbody"),n=i.selectAll("tr").data(function(e){return e.series}).enter().append("tr").classed("highlight",function(e){return e.highlight});n.append("td").classed("legend-color-guide",!0).append("div").style("background-color",function(e){return e.color}),n.append("td").classed("key",!0).classed("total",function(e){return!!e.total}).html(function(e,t){return w(e.key,t)}),n.append("td").classed("value",!0).html(function(e,t){return y(e.value,t)}),n.selectAll("td").each(function(e){if(e.highlight){var t=d3.scale.linear().domain([0,1]).range(["#fff",e.color]),a=.6;d3.select(this).style("border-bottom-color",t(a)).style("border-top-color",t(a))}});var r=t.node().outerHTML;return void 0!==e.footer&&(r+='<div class="footer">'+e.footer+"</div>"),r},M=function(e){if(e&&e.series){if(e.series instanceof Array)return!!e.series.length;if(e.series instanceof Object)return e.series=[e.series],!0}return!1},C=function(e){var t,a,i,o=d.node().offsetHeight,s=d.node().offsetWidth,l=document.documentElement.clientWidth,c=document.documentElement.clientHeight;switch(n){case"e":t=-s-r,a=-(o/2),e.left+t<0&&(t=r),(i=e.top+a)<0&&(a-=i),(i=e.top+a+o)>c&&(a-=i-c);break;case"w":t=r,a=-(o/2),e.left+t+s>l&&(t=-s-r),(i=e.top+a)<0&&(a-=i),(i=e.top+a+o)>c&&(a-=i-c);break;case"n":t=-(s/2)-5,a=r,e.top+a+o>c&&(a=-o-r),(i=e.left+t)<0&&(t-=i),(i=e.left+t+s)>l&&(t-=i-l);break;case"s":t=-(s/2),a=-o-r,e.top+a<0&&(a=r),(i=e.left+t)<0&&(t-=i),(i=e.left+t+s)>l&&(t-=i-l);break;case"center":t=-(s/2),a=-(o/2);break;default:t=0,a=0}return{left:t,top:a}},x=function(){nv.dom.read(function(){var e=v(),t=C(e),a=e.left+t.left,i=e.top+t.top;if(c)d.interrupt().transition().delay(p).duration(0).style("opacity",0);else{var n="translate("+u.left+"px, "+u.top+"px)",r="translate("+a+"px, "+i+"px)",o=d3.interpolateString(n,r),s=d.style("opacity")<.1;d.interrupt().transition().duration(s?0:m).styleTween("transform",function(){return o},"important").styleTween("-webkit-transform",function(){return o}).style("-ms-transform",r).style("opacity",1)}u.left=a,u.top=i})};return t.nvPointerEventsClass=f,t.options=nv.utils.optionsFunc.bind(t),t._options=Object.create({},{duration:{get:function(){return m},set:function(e){m=e}},gravity:{get:function(){return n},set:function(e){n=e}},distance:{get:function(){return r},set:function(e){r=e}},snapDistance:{get:function(){return o},set:function(e){o=e}},classes:{get:function(){return s},set:function(e){s=e}},chartContainer:{get:function(){return l},set:function(e){l=e}},enabled:{get:function(){return h},set:function(e){h=e}},hideDelay:{get:function(){return p},set:function(e){p=e}},contentGenerator:{get:function(){return k},set:function(e){k=e}},valueFormatter:{get:function(){return y},set:function(e){y=e}},headerFormatter:{get:function(){return b},set:function(e){b=e}},keyFormatter:{get:function(){return w},set:function(e){w=e}},headerEnabled:{get:function(){return g},set:function(e){g=e}},position:{get:function(){return v},set:function(e){v=e}},hidden:{get:function(){return c},set:function(e){c!==e&&(c=!!e,t())}},data:{get:function(){return i},set:function(e){e.point&&(e.value=e.point.x,e.series=e.series||{},e.series.value=e.point.y,e.series.color=e.point.color||e.series.color),i=e}},node:{get:function(){return d.node()},set:function(){}},id:{get:function(){return a},set:function(){}}}),nv.utils.initOptions(t),t},/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("chart",["d3","dashboard"])}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){function i(t){t.id=a.getId(),t.flags=e.flags;var i;nv.addGraph(function(){var e=250;return i=nv.models.lineChart().options({duration:0,useInteractiveGuideline:!0,interactive:!1,showLegend:!0,showXAxis:!0,showYAxis:!0}),i.margin({left:35,right:35}),i.height(e),t.forcey&&i.forceY([0,t.forcey]),i.x(a.xFunction()),i.y(a.yFunction()),i.xAxis.tickFormat(a.xAxisTickFormat()),t.percentage?i.yAxis.tickFormat(a.yAxisPercentageTickFormat()):t.integer?i.yAxis.tickFormat(a.yAxisIntegerTickFormat()):i.yAxis.tickFormat(a.yAxisTickFormat()),nv.utils.windowResize(i.update),d3.select("#"+t.id+" svg").datum(t.data).style("height",e+"px").transition().duration(0).call(i),i}),t.$on("updateMetrics",function(){t.area&&angular.forEach(t.data,function(e){e.area=!0}),i.update()})}return{restrict:"A",templateUrl:"app/components/chart/chart.html",scope:{data:"=",percentage:"=",integer:"=",forcey:"=",area:"="},link:i}}e.$inject=["$rootScope","$log","D3Service"],angular.module("chart").directive("lineTimeSeries",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a){function i(t){t.id=a.getId(),t.flags=e.flags,t.legend=!0;var i;nv.addGraph(function(){var e=a.yAxisTickFormat(),n=250;return i=nv.models.stackedAreaChart().options({duration:0,useInteractiveGuideline:!0,interactive:!1,showLegend:!0,showXAxis:!0,showYAxis:!0,showControls:!1}),i.margin({left:35,right:35}),i.height(n),t.forcey&&i.yDomain([0,t.forcey]),i.x(a.xFunction()),i.y(a.yFunction()),i.xAxis.tickFormat(a.xAxisTickFormat()),t.percentage?(e=a.yAxisPercentageTickFormat(),i.yAxis.tickFormat()):t.integer&&(e=a.yAxisIntegerTickFormat(),i.yAxis.tickFormat()),i.yAxis.tickFormat(e),nv.utils.windowResize(i.update),d3.select("#"+t.id+" svg").datum(t.data).style("height",n+"px").transition().duration(0).call(i),i}),t.$on("updateMetrics",function(){i.update()})}return{restrict:"A",templateUrl:"app/components/chart/chart.html",scope:{data:"=",percentage:"=",integer:"=",forcey:"="},link:i}}e.$inject=["$rootScope","$log","D3Service"],angular.module("chart").directive("areaStackedTimeSeries",e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i,n,r,o,s,l,c,p){function d(e){return F[u(e)]}function u(e){return null===e?!1:(-1!==e.indexOf("docker/")?e=e.split("/")[2]:-1!==e.indexOf("/docker-")&&(e=e.split("-")[1].split(".")[0]),e)}function h(){F={}}function m(e){return angular.isDefined(F[u(e)])&&""!==F[u(e)]}function g(){y(),t.properties.containerList=b(),O?-1===t.properties.containerList.indexOf(n.container)&&(t.properties.selectedContainer=""):angular.isDefined(n.container)?-1!==t.properties.containerList.indexOf(n.container)&&(t.properties.selectedContainer=n.container,t.flags.disableContainerSelectNone=!0,O=!0,M()):O=!0}function f(){D=p.getOrCreateMetric("containers.cgroup"),S=p.getOrCreateMetric("containers.name"),P=t.$on("updateMetrics",g)}function v(e){var t;return"undefined"==typeof x?!c.useCgroupId&&(t=_.find(S.data,function(t){return t.key===e}))?t.values[t.values.length-1].y:e.substring(0,12):(t=_.find(S.data,function(t){return t.key===e}),x.resolve(e,t))}function y(){F=D.data.reduce(function(e,t){return e[t.key]=v(t.key),e},{})}function b(){return D.data.reduce(function(e,t){var a=v(t.key);return angular.isDefined(a)&&e.push(a),e},[])}function w(e){return""===t.properties.containerFilter||-1!==e.indexOf(t.properties.containerFilter)}function k(e){return""===t.properties.selectedContainer||-1!==e.indexOf(t.properties.selectedContainer)}function M(){r.search("container",t.properties.selectedContainer),""!==t.properties.selectedContainer?t.flags.disableContainerSelectNone=!0:t.flags.disableContainerSelectNone=!1,l.setContainer(t.properties.context,t.properties.selectedContainer)}function C(){r.search("containerFilter",t.properties.containerFilter)}var x,O=!1;try{x=o.get("containerNameResolver")}catch(T){s.debug("No external container name resolver defined.")}var D,S,P,F={};return{idDictionary:d,getContainerList:b,updateIdDictionary:y,clearIdDictionary:h,checkContainerFilter:w,containerIdExist:m,checkContainerName:k,updateContainer:M,updateContainerFilter:C,initialize:f}}e.$inject=["$http","$rootScope","$q","$interval","$routeParams","$location","$injector","$log","PMAPIService","config","MetricListService"],angular.module("containermetadata",["metriclist"]).factory("ContainerMetadataService",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t,a,i,n,r,o,s,l,c,p,d,u){function h(){e[0].hidden||e[0].webkitHidden||e[0].mozHidden||e[0].msHidden?p.cancelInterval():p.updateInterval()}function m(){if(p.initialize(),n.protocol&&(t.properties.protocol=n.protocol),n.host&&(g.inputHost=n.host,n.hostspec&&(t.properties.hostspec=n.hostspec),p.updateHost(g.inputHost)),e[0].addEventListener("visibilitychange",h,!1),e[0].addEventListener("webkitvisibilitychange",h,!1),e[0].addEventListener("msvisibilitychange",h,!1),e[0].addEventListener("mozvisibilitychange",h,!1),angular.isDefined(n.widgets)){var a=n.widgets.split(",")||[];f=a.reduce(function(e,t){return e.concat(o.filter(function(e){return e.name===t}))},[])}else{var i=s.reduce(function(e,t){return e.push(t.name),e},[]).join();r.search("widgets",i)}angular.isDefined(n.containerFilter)&&(t.properties.containerFilter=n.containerFilter),g.dashboardOptions={hideToolbar:!0,widgetButtons:!1,hideWidgetName:!0,hideWidgetSettings:!1,widgetDefinitions:o,defaultWidgets:f}}var g=this,f=s;g.version=c.id,g.embed=l,g.addWidgetToURL=function(e){var t="";angular.isUndefined(n.widgets)?n.widgets="":t=",",e.length?(n.widgets="",t=e.reduce(function(e,t){return e.push(t.name),e},[]).join()):t+=e.name,r.search("widgets",n.widgets+t)},g.removeWidgetFromURL=function(e){for(var t=n.widgets.split(",")||[],a=0;a<t.length;a++)if(t[a]===e.name){t.splice(a,1);break}t.length<1?g.removeAllWidgetFromURL():r.search("widgets",t.toString())},g.removeAllWidgetFromURL=function(){r.search("widgets",null)},g.resetDashboard=function(){var e={closeButtonText:"Cancel",actionButtonText:"Ok",headerText:"Reset Dashboard",bodyText:"Are you sure you want to reset the dashboard?"};u.showModal({},e).then(function(){r.search("container",null),r.search("containerFilter",null),t.flags.disableContainerSelectNone=!1,t.properties.selectedContainer="",t.properties.containerFilter="",g.dashboardOptions.loadWidgets([]),g.removeAllWidgetFromURL()})},g.updateHost=function(){p.updateHost(g.inputHost),d.clearIdDictionary()},g.addWidget=function(e,t){e.preventDefault(),g.checkWidgetType(t)&&(g.dashboardOptions.addWidget(t),g.addWidgetToURL(t))},g.checkWidgetType=function(a){if(angular.isDefined(a.requireContainerFilter)&&a.requireContainerFilter===!0&&t.flags.disableContainerSelect===!1&&!t.flags.containerSelectOverride&&""===t.properties.selectedContainer){var i={closeButtonText:"",actionButtonText:"Ok",headerText:"Error: Container selection required.",bodyText:"This widget requires a container to be selected. Please select a container and try again."};return u.showModal({},i).then(function(){e.getElementById("selectedContainer").focus()}),!1}return!0},g.updateInterval=p.updateInterval,g.updateContainer=d.updateContainer,g.updateContainerFilter=d.updateContainerFilter,g.inputHost="",m()}e.$inject=["$document","$rootScope","$log","$route","$routeParams","$location","widgetDefinitions","widgets","embed","version","DashboardService","ContainerMetadataService","ModalService"],angular.module("main",["dashboard","widget","containermetadata","modal"]).controller("MainController",e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("vector",["ngRoute","ui.dashboard","toastr","main"])}(),function(){"use strict";angular.module("vector").constant("version",{id:"v1.1.2-38-g25df07e"})}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e){e.when("/",{templateUrl:"app/main/main.html",controller:"MainController",controllerAs:"vm",title:"Vector",reloadOnSearch:!1,resolve:{widgets:["defaultWidgets",function(e){return e}],embed:function(){return!1}}}).when("/embed",{templateUrl:"app/main/main.html",controller:"MainController",controllerAs:"vm",title:"Vector",reloadOnSearch:!1,resolve:{widgets:["defaultWidgets",function(e){return e}],embed:function(){return!0}}}).when("/empty",{templateUrl:"app/main/main.html",controller:"MainController",controllerAs:"vm",title:"Vector",reloadOnSearch:!1,resolve:{widgets:["emptyWidgets",function(e){return e}],embed:function(){return!1}}}).when("/container",{templateUrl:"app/main/main.html",controller:"MainController",controllerAs:"vm",title:"Vector",reloadOnSearch:!1,resolve:{widgets:["containerWidgets",function(e){return e}],embed:function(){return!1}}}).otherwise("/")}e.$inject=["$routeProvider"],angular.module("vector").config(e)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e,t){var a,i,n=[];for(a=0;a<e.length;a++)i=e[a][t],-1===n.indexOf(i)&&n.push(i);return n}function t(){return function(t,a){return null!==t?e(t,a):void 0}}function a(){return function(e,t){return e.filter(function(e){return e.group===t})}}angular.module("vector").filter("groupBy",t).filter("groupFilter",a)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("vector")}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e){e.decorator("$interval",["$delegate",function(e){var t=e.cancel;return e.cancel=function(e){var a=t(e);return a&&e&&(e.isCancelled=!0),a},e}])}e.$inject=["$provide"],angular.module("vector").config(e)}(),/**!
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";angular.module("vector").constant("moment",moment)}(),/**!
 *
 *  Copyright 2015 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
function(){"use strict";function e(e){e.allowHtml=!0,e.timeOut=8e3,e.positionClass="toast-top-right",e.preventDuplicates=!0,e.progressBar=!0}function t(e){e.debugEnabled(!0)}e.$inject=["toastrConfig"],t.$inject=["$logProvider"],angular.module("vector").constant("config",{protocol:"http",port:44323,hostspec:"localhost",interval:"2",window:"2",enableCpuFlameGraph:!1,enableContainerWidgets:!0,disableHostspecInput:!1,disableContainerFilter:!1,disableContainerSelect:!1,containerSelectOverride:!0,useCgroupId:!1,expandHostname:!1,disableHostnameInputContainerSelect:!1}).config(e).config(t)}(),angular.module("vector").run(["$templateCache",function(e){e.put("app/main/main.html",'<div class="navbar navbar-inverse navbar-fixed-top" role=navigation ng-if=!vm.embed><div class=container-fluid><div class=navbar-header><button type=button class=navbar-toggle data-toggle=collapse data-target=.navbar-collapse><span class=sr-only>Toggle navigation</span> <span class=icon-bar></span> <span class=icon-bar></span> <span class=icon-bar></span></button> <a class=navbar-brand href=#/ ><img ng-src=assets/images/vector_owl.png alt="Vector Owl" height=20></a><a class=navbar-brand href="javascript:window.location.reload(true);history.pushState(null, \'\', location.href.split(\'?\')[0]);">Vector</a></div></div></div><div class=dashboard-container ng-class="{ \'main-container\': !vm.embed }"><div class=row><div class=col-md-12><div dashboard=vm.dashboardOptions template-url=app/components/dashboard/dashboard.html class=dashboard-container></div></div></div></div>'),e.put("app/components/chart/chart.html",'<div><i class="fa fa-line-chart fa-5x widget-icon" ng-hide=flags.contextAvailable></i><div id={{id}} class=chart ng-hide=!flags.contextAvailable><svg></svg></div></div>'),e.put("app/components/cswflamegraphtask/cswflamegraph-help.html",'<h4>Summary</h4><p>Context switch flame graphs visualize code paths that block and wait off-CPU, such as for I/O and lock contention. This widget works by tracing scheduler context switches, then aggregating stack traces in kernel context for efficency using eBPF. Despite this, scheduler events are high frequency, and even tracing them in an efficient way may still cost some noticable overhead. This visualization shows the number of context switches. This runs as a background task until the trace is completed.</p><h4>Prerequisites: BPF Stacks</h4><p>This instrumentation requires BPF stack trace support, which arrived in the Linux 4.6 kernel.</p><h4>Overhead</h4><p>This instruments scheduler events, which can be very high frequency: tens of millions of events per second. While the instrumentation has been optimized using eBPF to be efficient, adding some CPU cycles to each event will add up, and for high rates of events may begin to cost noticable overhead. Because of this, the default duration is ten seconds instead of one minute. If you are unsure of the overhead effect, use in a test environment before production use.</p><h4>Flame Graph Visualization</h4><p>The x-axis shows the stack profile population, sorted alphabetically (it is not the passage of time), and the y-axis shows stack depth. Each rectangle represents a stack frame. The wider a frame is, the more frequently it was present in a code path that led to a block (regardless of the blocking duration). The top edge shows what blocked, and beneath it is its ancestry. The color is blue to indicate blocked time, and the saturation value is randomized to differentiate between frames.</p><h4>Interpretation &amp; Actionable Items</h4><p>This shows code paths that lead to blocking and waiting off-CPU, such as for disk I/O or lock contention. Ideally these can be minimized. Look for the widest stacks and investigate them first. To understand the duration that these spent off-CPU, use the off-CPU time flame graph.</p><p>The actionable fix depends on the code path. Disk I/O can be improved by reconfiguring the workloads on the system to allow for a larger file system cache, or switching to an instance with faster disks. Lock contention may be reduced by tuning thread pools to smaller counts, or by the developer modifying the code.</p><h4>Common Issues</h4><p><b>Broken stacks:</b> If the runtime does not expose a stack walker that the profiler can use (commonly frame-pointer based), then stack traces will be broken and ancestry will be missing. This is usually visible as a "bed of grass": thin frames all at the same level. The fix depends on the runtime and stack walking technique. Eg, to use frame-pointer walking with Java, Java must be run with -XX:+PreserveFramePointer.</p><p><b>Missing frames:</b> This shows the native stack trace, after inlining. Runtimes like the JVM can inline as much as 70% of all frames, which will be missing from the flame graph. Vector has an uninlined CPU flame graph task that can reveal these missing frames.</p><p><b>Missing symbols:</b> JIT runtimes need to export a symbol file for the profiler to use. This depends on the runtime. Java should be handled automatically by Vector, making use of perf-map-agent. Node.js currently needs to run with --perf_basic_prof_only_funcitons or --perf_basic_prof.</p><h4>Externel Resources</h4><ul><li>The <a href=http://www.brendangregg.com/flamegraphs.html>Flame Graphs homepage</a>.</li><li>There is an ACMQ article <a href="http://queue.acm.org/detail.cfm?id=2927301">The Flame Graph</a>, also published in <a href=http://cacm.acm.org/magazines/2016/6/202665-the-flame-graph/abstract>CACM</a>.</li></ul>'),e.put("app/components/cswflamegraphtask/cswflamegraph.html",'<div class=col-md-12><div class=row style="text-align: center"><p>Context switch stack tracing</p><button type=button class="btn btn-primary" ng-disabled=processing ng-click=generateCSwFlameGraph()>Generate Context Switch Flame Graph<i ng-if=processing class="fa fa-refresh fa-spin"></i></button> seconds:<select class=select ng-model=secondselected style=margin-top:7px><option ng-repeat="x in secondoptions">{{x}}</option></select></div><div class=row style="margin-top: 10px">Status: {{statusmsg}}</div><div class=row ng-if="!processing && ready" style="text-align: center; margin-top: 15px"><p>The CPU flame graph is ready. Please click on the button below to open it.</p><a class="btn btn-default" href=http://{{host}}:{{port}}/{{svgname}} target=_blank>Open Flame Graph</a></div></div>'),e.put("app/components/customWidgetHelp/customWidgetHelp.html",'<div class=modal-header><button type=button class=close data-dismiss=modal aria-hidden=true ng-click=cancel()>&times;</button><h3>Widget Help <small>{{widget.title}}</small></h3></div><div class=modal-body><div ng-include=widget.help_url></div></div><div class=modal-footer><button type=button class="btn btn-primary" ng-click=ok()>Close</button></div>'),e.put("app/components/customWidgetSettings/customWidgetSettings.html",'<div class=modal-header><button type=button class=close data-dismiss=modal aria-hidden=true ng-click=cancel()>&times;</button><h3>Widget Options <small>{{widget.title}}</small></h3></div><div class=modal-body><form name=form novalidate class=form-horizontal><div class=input-group><span class=input-group-addon>Filter</span> <input class="widgetInput form-control" name=widgetFilter ng-model=result.filter ng-change="vm.updateFilterWidget(this.widget, result)" ng-keydown="$event.which === 13 && ok()"></div></form></div><div class=modal-footer><button type=button class="btn btn-default" ng-click="cancel(); vm.clearFilterWidget(this.widget);">Cancel</button> <button type=button class="btn btn-primary" ng-click=ok()>OK</button></div>'),e.put("app/components/dashboard/dashboard.html",'<div class=row ng-if=!vm.embed><div class=col-md-6><form role=form name=form><div class="input-group input-group-lg target" ng-class="{\'has-error\': form.host.$invalid && form.host.$dirty}"><span class=input-group-addon ng-click="flags.isHostnameExpanded = !flags.isHostnameExpanded;">Hostname &nbsp; <i class="fa fa-plus-square-o" ng-if=!flags.isHostnameExpanded></i><i class="fa fa-minus-square-o" ng-if=flags.isHostnameExpanded></i></span> <input type=text class="form-control hostname-input" id=hostnameInput name=host data-content="Please enter the instance hostname. Port can be specified using the <hostname>:<port> format. Expand to change hostspec." rel=popover data-placement=bottom data-trigger=hover data-container=body ng-model=vm.inputHost ng-change=vm.updateHost() ng-model-options="{ updateOn: \'default\', debounce: 1000 }" delay=1000 ng-disabled="flags.contextUpdating == true || ( flags.disableContainerSelectNone && flags.disableHostnameInputContainerSelect)" required placeholder="Instance Hostname"> <i class="fa fa-refresh fa-2x form-control-feedback" ng-if=flags.contextUpdating></i> <i class="fa fa-check fa-2x form-control-feedback" ng-if=flags.contextAvailable></i></div></form></div><div class="btn-group col-md-2 widget-wrapper" id=widgetWrapper><button id=widgetButton type=button class="dropdown-toggle btn btn-lg btn-default btn-block widget-button" data-toggle=dropdown>Widget <span class=caret></span></button><ul class=dropdown-menu role=menu><li class=dropdown-submenu ng-repeat="group in widgetDefs | groupBy: \'group\'"><a ng-click=void(0) data-toggle=dropdown>{{group}}</a><ul class=dropdown-menu><li ng-repeat="widget in widgetDefs | groupFilter: group"><a ng-click="vm.addWidget($event, widget);">{{widget.title}}</a></li></ul></li><li role=presentation class=divider></li><li><a href=javascript:void(0); ng-click="loadWidgets(defaultWidgets); vm.addWidgetToURL(defaultWidgets);">Default Widgets</a></li><li><a href=javascript:void(0); ng-click="loadWidgets(emptyWidgets); vm.removeAllWidgetFromURL();">Clear Widgets</a></li><li role=presentation class=divider></li><li><a href=javascript:void(0); ng-click=vm.resetDashboard();>Reset Dashboard</a></li></ul></div><div class=col-md-2><form role=form><div class="input-group input-group-lg window" ng-class="{\'has-error\': form.window.$invalid && form.window.$dirty}"><span class=input-group-addon>Window</span><select class=form-control name=window id=windowInput data-content="The duration window for all charts in this dashboard." rel=popover data-placement=bottom data-trigger=hover data-container=body ng-model=properties.window ng-change=vm.updateWindow()><option value=2>2 min</option><option value=5>5 min</option><option value=10>10 min</option></select></div></form></div><div class=col-md-2><form role=form><div class="input-group input-group-lg interval" ng-class="{\'has-error\': form.interval.$invalid && form.interval.$dirty}"><span class=input-group-addon>Interval</span><select class=form-control name=interval id=intervalInput data-content="The update interval used by all charts in this dashboard." rel=popover data-placement=bottom data-trigger=hover data-container=body ng-model=properties.interval ng-change=vm.updateInterval()><option value=1>1 sec</option><option value=2>2 sec</option><option value=3>3 sec</option><option value=5>5 sec</option></select></div></form></div></div><div class=row ng-show=flags.isHostnameExpanded ng-if=!vm.embed><div class=col-md-6><form role=form name=form><div class="input-group input-group-lg target" ng-show=!flags.disableHostspecInput ng-class="{\'has-error\': form.hostspec.$invalid && form.hostspec.$dirty}"><span class=input-group-addon>Hostspec</span> <input type=text class=form-control id=hostspecInput name=host data-content="Please enter the instance hostspec." rel=popover data-placement=bottom data-trigger=hover data-container=body ng-model=properties.hostspec ng-change=vm.updateHost() ng-model-options="{ updateOn: \'default\', debounce: 1000 }" delay=1000 ng-disabled="flags.contextUpdating == true || ( flags.disableContainerSelectNone && flags.disableHostnameInputContainerSelect )" required placeholder="Instance Hostspec"></div><div class="input-group input-group-lg target" ng-show="flags.enableContainerWidgets && !flags.disableContainerFilter"><span class=input-group-addon>Container Filter</span> <input type=text class=form-control id=globalFilterInput name=globalFilter data-content="Global filter for container widgets" rel=popover data-placement=bottom data-trigger=hover data-container=body ng-model=properties.containerFilter ng-change=vm.updateContainerFilter() ng-model-options="{ updateOn: \'default\', debounce: 1000 }" delay=1000 placeholder="Container Filter"></div><div class="input-group input-group-lg target" ng-show="flags.enableContainerWidgets && !flags.disableContainerSelect"><span class=input-group-addon>Container Id</span><select id=selectedContainer ng-model=properties.selectedContainer ng-change=vm.updateContainer() class=form-control><option ng-disabled="flags.disableContainerSelectNone && !flags.containerSelectOverride" value="">All</option><option ng-repeat="container in properties.containerList">{{container}}</option></select></div></form></div><div class=col-md-6><p class="lead hostname-label" id=hostnameLabel data-content="PMCD hostname. The hostname from the actual instance you\'re monitoring." rel=popover data-placement=bottom data-trigger=hover data-container=body>{{flags.contextAvailable && properties.hostname ? properties.hostname : \'Disconnected\'}}</p></div></div><div class=row><div class=col-md-12><div class=btn-toolbar ng-if=!options.hideToolbar><div class=btn-group ng-if=!options.widgetButtons><button type=button class="dropdown-toggle btn btn-primary" data-toggle=dropdown>Add Widget <span class=caret></span></button><ul class=dropdown-menu role=menu><li ng-repeat="widget in widgetDefs"><a href=# ng-click="addWidgetInternal($event, widget);"><span class="label label-primary">{{widget.name}}</span></a></li></ul></div><div class=btn-group ng-if=options.widgetButtons><button ng-repeat="widget in widgetDefs" ng-click="addWidgetInternal($event, widget);" type=button class="btn btn-primary">{{widget.name}}</button></div><button class="btn btn-warning" ng-click=resetWidgetsToDefault()>Default Widgets</button> <button ng-if="options.storage && options.explicitSave" ng-click=options.saveDashboard() class="btn btn-success" ng-disabled=!options.unsavedChangeCount>{{ !options.unsavedChangeCount ? "all saved" : "save changes (" + options.unsavedChangeCount + ")" }}</button> <button ng-click=clear(); type=button class="btn btn-info">Clear</button></div><div ui-sortable=sortableOptions ng-model=widgets class=dashboard-widget-area><div ng-repeat="widget in widgets" ng-style=widget.containerStyle class=widget-container widget><div class="widget panel panel-default"><div class="widget-header panel-heading"><h3 class=panel-title><span class=widget-title>{{widget.title}}</span><!-- <span class="widget-title" ng-dblclick="editTitle(widget)" ng-hide="widget.editingTitle">{{widget.title}}</span> --><!-- <form action="" class="widget-title" ng-show="widget.editingTitle" ng-submit="saveTitleEdit(widget)">\n                                <input type="text" ng-model="widget.title" class="form-control">\n                            </form> --> <span class="label label-primary" ng-if=!options.hideWidgetName>{{widget.name}}</span> <span title="Close widget" ng-click="removeWidget(widget);  vm.removeWidgetFromURL(widget);" class="glyphicon glyphicon-remove" ng-if=!options.hideWidgetClose></span> <span title=Settings ng-click=openWidgetSettings(widget); class="glyphicon glyphicon-cog" ng-if="!options.hideWidgetSettings && widget.hasLocalSettings"></span> <span title="Help documentation" ng-click=openWidgetSettings(widget); class="glyphicon glyphicon-question-sign" ng-if=widget.hasLocalHelp></span> <span title="May cost high overhead, see help" onclick="alert(\'WARNING: May cost high overhead. See the Overhead section in the help documentation for details.\')" class="glyphicon glyphicon-alert" ng-if=widget.hasHighOverhead></span> <span title="Container aware" onclick="alert(\'If a container is selected, this widget will instrument that container only (container aware).\')" class="glyphicon glyphicon glyphicon-ok-circle" ng-if=widget.isContainerAware></span></h3></div><div class="panel-body widget-content" ng-style=widget.contentStyle></div><div class=widget-ew-resizer ng-mousedown=grabResizer($event)></div><div ng-if=widget.enableVerticalResize class=widget-s-resizer ng-mousedown=grabSouthResizer($event)></div></div></div></div></div></div><div class="row version-div" ng-if=!vm.embed>Version: {{vm.version}}</div><script>(function () {\n        \'use strict\';\n        $(\'#hostnameInput\').popover();\n        $(\'#hostspecInput\').popover();\n        $(\'#globalFilterInput\').popover();\n        $(\'#windowInput\').popover();\n        $(\'#intervalInput\').popover();\n        $(\'#hostnameLabel\').popover();\n    }());</script>'),e.put("app/components/diskioflamegraphtask/diskioflamegraph-help.html",'<h4>Summary</h4><p>Disk I/O flame graphs visualize code that directly requested disk I/O, helping explain the cause of disk I/O. This widget works by tracing whenever a disk I/O event is enqueued. It runs as a background task until the profile is completed.</p><p></p><h4>Overhead</h4><p>This should have low overhead while tracing, and then a short period (seconds) of a single CPU runtime at the end as symbols are collected and the flame graph is generated. Relative to other events, disk I/O is usually a low rate activity, hence the low overhead. There are some exceptions: a large database server may be calling tens of thousands of disk I/O per second, which will have a higher overhead to trace, not just for the extra CPU cycles, but also for the file system and storage I/O to store the trace data. If you suspect you have a high overhead case, test and measure overhead before production use.</p><h4>Disk I/O Tracing</h4><p>The intent here is to show which code paths are causing disk I/O. It workes by tracing when disk I/O events are inserted on a storage queue to be later issued to the device. (This uses the Linux tracepoint: block:block_rq_insert.) This approach is simple and usually identifies the code path of interest. There are worse approaches: for example, mesauring when the disk I/O actually begins, which is often asynchronous to the request, and so does not identify the code path of interest.</p><h4>Flame Graph Visualization</h4><p>The x-axis shows the stack profile population, sorted alphabetically (it is not the passage of time), and the y-axis shows stack depth. Each rectangle represents a stack frame. The wider a frame is is, the more often it was present in the profile. The top edge shows what directly triggered a disk I/O request to be queued, and beneath it is its ancestry. The x-axis width is relative to the number of I/O. Different color hues are used for different code types, and the saturation is randomized to differentiate between frames.</p><h4>Common Issues</h4><p><b>Broken stacks:</b> If the runtime does not expose a stack walker that the profiler can use (commonly frame-pointer based), then stack traces will be broken and ancestry will be missing. This is usually visible as a "bed of grass": thin frames all at the same level. The fix depends on the runtime and stack walking technique. Eg, to use frame-pointer walking with Java, Java must be run with -XX:+PreserveFramePointer.</p><p><b>Missing frames:</b> This shows the native stack trace, after inlining. Runtimes like the JVM can inline as much as 70% of all frames, which will be missing from the fla me graph. Vector has an uninlined CPU flame graph task that can reveal these missing frames.</p><p><b>Missing symbols:</b> JIT runtimes need to export a symbol file for the profiler to use. This depends on the runtime. Java should be handled automatically by Vector, making use of perf-map-agent. Node.js currently needs to run with --perf_basic_prof_only_funcitons or --perf_basic_prof.</p><h4>Externel Resources</h4><ul><li>The <a href=http://www.brendangregg.com/flamegraphs.html>Flame Graphs homepage</a> has a page on <a href=http://www.brendangregg.com/FlameGraphs/memoryflamegraphs.html>Memory Flame Graphs</a>, which includes a section on page fault tracing.</li><li>There is an ACMQ article <a href="http://queue.acm.org/detail.cfm?id=2927301">The Flame Graph</a>, also published in <a href=http://cacm.acm.org/magazines/2016/6/202665-the-flame-graph/abstract>CACM</a>.</li></ul>'),e.put("app/components/diskioflamegraphtask/diskioflamegraph.html",'<div class=col-md-12><div class=row style="text-align: center"><p>Disk I/O stack tracing</p><button type=button class="btn btn-primary" ng-disabled=processing ng-click=generateDiskIOFlameGraph()>Generate Disk I/O Flame Graph<i ng-if=processing class="fa fa-refresh fa-spin"></i></button> seconds:<select class=select ng-model=secondselected style=margin-top:7px><option ng-repeat="x in secondoptions">{{x}}</option></select></div><div class=row style="margin-top: 10px">Status: {{statusmsg}}</div><div class=row ng-if="!processing && ready" style="text-align: center; margin-top: 15px"><p>The flame graph is ready. Please click on the button below to open it.</p><a class="btn btn-default" href=http://{{host}}:{{port}}/{{svgname}} target=_blank>Open Flame Graph</a></div></div>'),e.put("app/components/ipcflamegraphtask/ipcflamegraph-help.html",'<h4>Summary</h4><p>IPC flame graphs visualize code that is consuming CPUs, and uses a color spectrum to indicate the instructions-per-cycle (IPC) for individual functions: red means instruction heavier, and blue means cycle heavier (usually stall cycles). This widget works by using a profiler that does overflow-based sampling of stack traces for CPU cycle and instruction events via performance monitoring counters (PMCs), on all running CPUs. Only one in 100 million events are sampled. This runs as a background task until the profile is completed. This only works if PMCs are available on the server, which for many cloud instance types will not be.</p><p></p><h4>Overhead</h4><p>This should have negligible overhead while profiling, and then a short period (seconds) of a single CPU runtime at the end as symbols are collected and the flame graph generated.</p><h4>PMCs</h4><p>Performance monitoring counters (PMCs) are special programmable hardware counters that report low-level processor behavior. In many cloud environments they are currently disabled. They should currently be available for the largest instance types on AWS EC2. To test at the command line, on Linux, run "perf stat ls" and see if the cycles and instructions counters are measured (if not, they will report "&lt;not supported&gt;").</p><h4>IPC Profiling</h4><p>Instructions-per-cycle (IPC) is a PMC-based metric commonly used as a starting point for understanding for low-level CPU behavior, particularly whether code is limited by the speed of instruction execution or other resources (usually main memory). The higher the IPC, the more quickly the processor is completing instructions (aka "retiring" instructions). The are many more PMCs for providing more information when desired.</p><h4>Flame Graph Visualization</h4><p>The x-axis shows the stack profile population, sorted alphabetically (it is not the passage of time), and the y-axis shows stack depth. Each rectangle represents a stack frame. The wider a frame is, the more often it was present in the profile of CPU cycles (equivalent to a CPU flame graph). The top edge shows what is on-CPU, and beneath it is its ancestry. Different color hues are used to show the range of IPC values present in the profile, from red (more instruction heavy) to blue (more cycle heavy). The color spectrum is relative to each flame graph, so the most blue frame in one flame graph may have a different IPC to the most blue frame in another. The gloabal IPC value for the flame graph is shown in the subtitle.</p><h4>Interpretation &amp; Actionable Items</h4><p>If functions are colored red, they are instruction heavy (with a high IPC), if they are colored blue, they are cycle heavy (a low IPC) and likely stalled on memory I/O.</p><p></p><p>Examples of instruction optimizations:</p><ul><li>&ndash; by the system administrator: choosing systems with faster processors, disabling hyperthreads, reducing CPU contention.</li><li>&ndash; by the developer: finding and eliminating unnecessary work, using faster algorithms.</li></ul><p>Examples of memory I/O optimizations:</p><ul><li>&ndash; by the system administrator: using different system NUMA settings, using different memory settings including large pages, and choosing systems with larger CPU caches or with faster main memory.</li><li>&ndash; by the developer: changing the code to do fewer memory copies and object allocations, and using more memory efficient data structures.</li></ul><p>As for the IPC value shown in the subtitle: interpreting this depends on the processor and its superscalar retire width. For example, many modern processors can retire four instructions with every cycle, which means its top speed IPC is 4.0 (when executing NOPs). For a production workload that involves memory I/O, an IPC of 1.5 may be considered good (it depends).</p><h4>Common Issues</h4><p><b>ERROR PMCs not available on this instance (see help)</b>: This is commonly the case in the cloud. See the earlier PMCs section.</p><p><b>Broken stacks:</b> If the runtime does not expose a stack walker that the profiler can use (commonly frame-pointer based), then stack traces will be broken and ancestry will be missing. This is usually visible as a "bed of grass": thin frames all at the same level. The fix depends on the runtime and stack walking technique. Eg, to use frame-pointer walking with Java, Java must be run with -XX:+PreserveFramePointer.</p><p><b>Missing frames:</b> This shows the native stack trace, after inlining. Runtimes like the JVM can inline as much as 70% of all frames, which will be missing from the flame graph. Vector has an uninlined CPU flame graph task that can reveal these missing frames.</p><p><b>Missing symbols:</b> JIT runtimes need to export a symbol file for the profiler to use. This depends on the runtime. Java should be handled automatically by Vector, making use of perf-map-agent. Node.js currently needs to run with --perf_basic_prof_only_funcitons or --perf_basic_prof.</p><h4>Externel Resources</h4><ul><li>A post on <a href=http://www.brendangregg.com/blog/2014-10-31/cpi-flame-graphs.html>CPI Flame Graphs</a> (CPI is IPC inverted, but otherwise this is the same thing).</li><li>The <a href=http://www.brendangregg.com/flamegraphs.html>Flame Graphs homepage</a>.</li><li>There is an ACMQ article <a href="http://queue.acm.org/detail.cfm?id=2927301">The Flame Graph</a>, also published in <a href=http://cacm.acm.org/magazines/2016/6/202665-the-flame-graph/abstract>CACM</a>.</li></ul>'),e.put("app/components/ipcflamegraphtask/ipcflamegraph.html",'<div class=col-md-12><div class=row style="text-align: center"><p>Timed CPU stack sampling</p><button type=button class="btn btn-primary" ng-disabled=processing ng-click=generateIPCFlameGraph()>Generate IPC Flame Graph<i ng-if=processing class="fa fa-refresh fa-spin"></i></button> seconds:<select class=select ng-model=secondselected style=margin-top:7px><option ng-repeat="x in secondoptions">{{x}}</option></select></div><div class=row style="margin-top: 10px">Status: {{statusmsg}}</div><div class=row ng-if="!processing && ready" style="text-align: center; margin-top: 15px"><p>The CPU flame graph is ready. Please click on the button below to open it.</p><a class="btn btn-default" href=http://{{host}}:{{port}}/{{svgname}} target=_blank>Open Flame Graph</a></div></div>'),e.put("app/components/flamegraph/flamegraph-help.html",'<h4>Summary</h4><p>CPU flame graphs visualize code that is consuming CPUs. This widget works using a profiler that does timed sampling of stack traces at 49 Hertz, on all running CPUs. It runs as a background task until the profile is completed.</p><p></p><h4>Overhead</h4><p>This should have negligible overhead while profiling, and then a short period (seconds) of a single CPU runtime at the end as symbols are collected and the flame graph generated.</p><h4>CPU Profiling</h4><p>Timed sampling of stack traces is a common industry method for understanding CPU usage with low overhead. This is different to tracing of all functions/methods, which is performed by some CPU profilers and costs high overhead and often skews results (observer effect).</p><h4>Flame Graph Visualization</h4><p>The x-axis shows the stack profile population, sorted alphabetically (it is not the passage of time), and the y-axis shows stack depth. Each rectangle represents a stack frame. The wider a frame is is, the more often it was present in the profile. The top edge shows what is on-CPU, and beneath it is its ancestry. Different color hues are used for different code types, and the saturation is randomized to differentiate between frames.</p><h4>Common Issues</h4><p><b>Broken stacks:</b> If the runtime does not expose a stack walker that the profiler can use (commonly frame-pointer based), then stack traces will be broken and ancestry will be missing. This is usually visible as a "bed of grass": thin frames all at the same level. The fix depends on the runtime and stack walking technique. Eg, to use frame-pointer walking with Java, Java must be run with -XX:+PreserveFramePointer.</p><p><b>Missing frames:</b> This shows the native stack trace, after inlining. Runtimes like the JVM can inline as much as 70% of all frames, which will be missing from the flame graph. Vector has an uninlined CPU flame graph task that can reveal these missing frames.</p><p><b>Missing symbols:</b> JIT runtimes need to export a symbol file for the profiler to use. This depends on the runtime. Java should be handled automatically by Vector, making use of perf-map-agent. Node.js currently needs to run with --perf_basic_prof_only_funcitons or --perf_basic_prof.</p><h4>Externel Resources</h4><ul><li>The <a href=http://www.brendangregg.com/flamegraphs.html>Flame Graphs homepage</a> has a page on <a href=http://www.brendangregg.com/FlameGraphs/cpuflamegraphs.html>CPU Flame Graphs</a>.</li><li>There is an ACMQ article <a href="http://queue.acm.org/detail.cfm?id=2927301">The Flame Graph</a>, also published in <a href=http://cacm.acm.org/magazines/2016/6/202665-the-flame-graph/abstract>CACM</a>.</li></ul>'),e.put("app/components/flamegraph/flamegraph.html",'<div class=col-md-12><div class=row style="text-align: center"><p>Timed CPU stack sampling</p><button type=button class="btn btn-primary" ng-disabled=processing ng-click=generateFlameGraph()>Generate CPU Flame Graph<i ng-if=processing class="fa fa-refresh fa-spin"></i></button> seconds:<select class=select ng-model=secondselected style=margin-top:7px><option ng-repeat="x in secondoptions">{{x}}</option></select></div><div class=row style="margin-top: 10px">Status: {{statusmsg}}</div><div class=row ng-if="!processing && ready" style="text-align: center; margin-top: 15px"><p>The CPU flame graph is ready. Please click on the button below to open it.</p><a class="btn btn-default" href=http://{{host}}:{{port}}/{{svgname}} target=_blank>Open Flame Graph</a></div></div>'),e.put("app/components/offcpuflamegraphtask/offcpuflamegraph-help.html",'<h4>Summary</h4><p>Off-CPU time flame graphs visualize code paths that block and wait off-CPU, such as for I/O and lock contention, and is a complementary visualization to CPU flame graphs. This widget works by tracing scheduler context switches, then aggregating stack traces in kernel context for efficency using eBPF. Despite this, scheduler events are high frequency, and even tracing them in an efficient way may still cost some noticable overhead. This runs as a background task until the trace is completed.</p><h4>Prerequisites: BPF Stacks</h4><p>This instrumentation requires BPF stack trace support, which arrived in the Linux 4.6 kernel.</p><h4>Overhead</h4><p>This instruments scheduler events, which can be very high frequency: tens of millions of events per second. While the instrumentation has been optimized using eBPF to be efficient, adding some CPU cycles to each event will add up, and for high rates of events may begin to cost noticable overhead. Because of this, the default duration is ten seconds instead of one minute. If you are unsure of the overhead effect, use in a test environment before production use.</p><h4>Flame Graph Visualization</h4><p>The x-axis shows the stack profile population, sorted alphabetically (it is not the passage of time), and the y-axis shows stack depth. Each rectangle represents a stack frame. The wider a frame is, the more often it was present in the trace of off-CPU time. The top edge shows what blocked, and beneath it is its ancestry. The color is blue to indicate blocked time, and the saturation value is randomized to differentiate between frames.</p><h4>Interpretation &amp; Actionable Items</h4><p>Look for applications of interest (the process name is the bottom frame), and then brows its blocked stacks from the widest to the thinnest. There will likely be many paths that are the application waiting for work, and so the stack trace is not interesting. Those are often the widest. Look for paths that occur during an application request, such as for lock contention and disk I/O.</p><p>The actionable fix depends on the code path. Disk I/O time can be improved by reconfiguring the workloads on the system to allow for a larger file system cache, or switching to an instance with faster disks. Lock contention may be reduced by tuning thread pools to smaller counts, or by the developer modifying the code.</p><h4>Common Issues</h4><p><b>Broken stacks:</b> If the runtime does not expose a stack walker that the profiler can use (commonly frame-pointer based), then stack traces will be broken and ancestry will be missing. This is usually visible as a "bed of grass": thin frames all at the same level. The fix depends on the runtime and stack walking technique. Eg, to use frame-pointer walking with Java, Java must be run with -XX:+PreserveFramePointer.</p><p><b>Missing frames:</b> This shows the native stack trace, after inlining. Runtimes like the JVM can inline as much as 70% of all frames, which will be missing from the flame graph. Vector has an uninlined CPU flame graph task that can reveal these missing frames.</p><p><b>Missing symbols:</b> JIT runtimes need to export a symbol file for the profiler to use. This depends on the runtime. Java should be handled automatically by Vector, making use of perf-map-agent. Node.js currently needs to run with --perf_basic_prof_only_funcitons or --perf_basic_prof.</p><h4>Externel Resources</h4><ul><li>The <a href=http://www.brendangregg.com/flamegraphs.html>Flame Graphs homepage</a> has a page on <a href=http://www.brendangregg.com/FlameGraphs/offcpuflamegraphs.html>Off-CPU Time Flame Graphs</a>.</li><li>A post on <a href=http://www.brendangregg.com/blog/2016-01-20/ebpf-offcpu-flame-graph.html>Linux eBPF Off-CPU Flame Graphs</a> (since then, real eBPF stack support has arrived in the kernel, which Vector uses).</li><li>There is an ACMQ article <a href="http://queue.acm.org/detail.cfm?id=2927301">The Flame Graph</a>, also published in <a href=http://cacm.acm.org/magazines/2016/6/202665-the-flame-graph/abstract>CACM</a>.</li></ul>'),
e.put("app/components/offcpuflamegraphtask/offcpuflamegraph.html",'<div class=col-md-12><div class=row style="text-align: center"><p>Off-CPU time stack tracing</p><button type=button class="btn btn-primary" ng-disabled=processing ng-click=generateOffCPUFlameGraph()>Generate Off-CPU Time Flame Graph<i ng-if=processing class="fa fa-refresh fa-spin"></i></button> seconds:<select class=select ng-model=secondselected style=margin-top:7px><option ng-repeat="x in secondoptions">{{x}}</option></select></div><div class=row style="margin-top: 10px">Status: {{statusmsg}}</div><div class=row ng-if="!processing && ready" style="text-align: center; margin-top: 15px"><p>The flame graph is ready. Please click on the button below to open it.</p><a class="btn btn-default" href=http://{{host}}:{{port}}/{{svgname}} target=_blank>Open Flame Graph</a></div></div>'),e.put("app/components/offwakeflamegraphtask/offwakeflamegraph-help.html",'<h4>Summary</h4><p>Off-Wake time flame graphs visualize code paths that block and wait off-CPU, such as for I/O and lock contention, and include both the blocked stack and the waker stack. This is an advanced visualization that works by tracing blocking and wakeup scheduler events, then associating and aggregating stack traces in kernel context for efficency using eBPF. Despite this, scheduler events are high frequency, and even tracing them in an efficient way may still cost some noticable overhead. This runs as a background task until the trace is completed.</p><h4>Prerequisites: BPF Stacks</h4><p>This instrumentation requires BPF stack trace support, which arrived in the Linux 4.6 kernel.</p><h4>Overhead</h4><p>This instruments scheduler switch and wakeup events, which can be very high frequency: tens of millions of events per second, and saves wakeup stacks in kernel memory to associate with blocked stacks. While the instrumentation has been optimized using eBPF to be efficient, adding some CPU cycles and memory usage to each event will add up, and for high rates of events this may cost significant overhead. Because of this, the default duration is five seconds instead of one minute. If you are unsure of the overhead effect, use in a test environment before production use.</p><h4>Flame Graph Visualization</h4><p>The x-axis shows the stack profile population, sorted alphabetically (it is not the passage of time), and the y-axis shows stack depth. Each rectangle represents a stack frame. The wider a frame is, the more often it was present in the trace of off-CPU time. The saturation value is randomized to differentiate between frames.</p><p>In shades of blue, and up until a "--" delimiter frame, is the blocking (off-CPU) stack trace. The top frame of this shows what blocked, and beneath it is its ancestry. The very bottom frame is the process name. The width is how long it was blocked off-CPU.</p><p>In shades of aqua, above a "--" delimiter frame, is the wakeup stack trace. This is in reverse order, so the bottom frame is the top of the stack which did the wakeup, and everything above it is ancestry. This reversing allows the wakeup frame to meet the blocked frame that it woke up in the middle. The very top frame is the process name that did the wakeup.</p><h4>Interpretation &amp; Actionable Items</h4><p>Look for applications of interest (the process name is the bottom frame), and then brows its blocked stacks from the widest to the thinnest. There will likely be many paths that are the application waiting for work, and so the stack trace is not interesting. Those are often the widest. Look for paths that occur during an application request, such as for lock contention and disk I/O. You can browse the wakeup stacks for more context on why something was blocked.</p><p>The actionable fix depends on the code path. Disk I/O time can be improved by reconfiguring the workloads on the system to allow for a larger file system cache, or switching to an instance with faster disks. Lock contention may be reduced by tuning thread pools to smaller counts, or by the developer modifying the code.</p><h4>Common Issues</h4><p><b>Broken stacks:</b> If the runtime does not expose a stack walker that the profiler can use (commonly frame-pointer based), then stack traces will be broken and ancestry will be missing. This is usually visible as a "bed of grass": thin frames all at the same level. The fix depends on the runtime and stack walking technique. Eg, to use frame-pointer walking with Java, Java must be run with -XX:+PreserveFramePointer.</p><p><b>Missing frames:</b> This shows the native stack trace, after inlining. Runtimes like the JVM can inline as much as 70% of all frames, which will be missing from the flame graph. Vector has an uninlined CPU flame graph task that can reveal these missing frames.</p><p><b>Missing symbols:</b> JIT runtimes need to export a symbol file for the profiler to use. This depends on the runtime. Java should be handled automatically by Vector, making use of perf-map-agent. Node.js currently needs to run with --perf_basic_prof_only_funcitons or --perf_basic_prof.</p><h4>Externel Resources</h4><ul><li>The <a href=http://www.brendangregg.com/flamegraphs.html>Flame Graphs homepage</a>.</li><li>A post on <a href=http://www.brendangregg.com/blog/2016-02-01/linux-wakeup-offwake-profiling.html>Linux Wakeup and Off-Wake Profiling</a> (since then, real eBPF stack support has arrived in the kernel, which Vector uses).</li><li>There is an ACMQ article <a href="http://queue.acm.org/detail.cfm?id=2927301">The Flame Graph</a>, also published in <a href=http://cacm.acm.org/magazines/2016/6/202665-the-flame-graph/abstract>CACM</a>.</li></ul>'),e.put("app/components/offwakeflamegraphtask/offwakeflamegraph.html",'<div class=col-md-12><div class=row style="text-align: center"><p>Off-Wake time stack tracing</p><button type=button class="btn btn-primary" ng-disabled=processing ng-click=generateOffWakeFlameGraph()>Generate Off-Wake Time Flame Graph<i ng-if=processing class="fa fa-refresh fa-spin"></i></button> seconds:<select class=select ng-model=secondselected style=margin-top:7px><option ng-repeat="x in secondoptions">{{x}}</option></select></div><div class=row style="margin-top: 10px">Status: {{statusmsg}}</div><div class=row ng-if="!processing && ready" style="text-align: center; margin-top: 15px"><p>The flame graph is ready. Please click on the button below to open it.</p><a class="btn btn-default" href=http://{{host}}:{{port}}/{{svgname}} target=_blank>Open Flame Graph</a></div></div>'),e.put("app/components/pagefaultflamegraphtask/pagefaultflamegraph-help.html",'<h4>Summary</h4><p>Page fault flame graphs visualize code that is triggering page faults, which can explain application memory growth (the growth of resident set size: RSS). This widget works by tracing page faults on all running CPUs. It runs as a background task until the profile is completed.</p><p></p><h4>Overhead</h4><p>This should have low overhead while tracing, and then a short period (seconds) of a single CPU runtime at the end as symbols are collected and the flame graph generated. Page faults are usually a low rate activity, hence the low overhead. There are some exceptions: software builds that use hundreds of short-lived processes per second can have a much higher rate of page faults, as well as applications that are growing RSS quickly. In such cases, this task may have a higher overhead, not just for the extra CPU cycles, but also for the file system and storage I/O to store the trace data. If you suspect you have a high overhead case, test and measure overhead before production use.</p><h4>Page Fault Tracing</h4><p>This is one way to analyze memory growth, in this case, the growth of resident set size (RSS).</p><p>Linux (like most operating systems) uses on-demand memory page allocation. When an application allocates memory (eg, malloc()), the operating system tracks the allocation but does not map physical memory to the process until it begins writing to it. At that point, the lie is revealed, and the processor\'s memory manangement unit (MMU) will "fault", as there is no virtual-to-physical mapping for the requested address. The kernel handles the fault, and makes the mapping. This is a normal way that processes end up using main memory, and defers the cost of allocation to later on, and only for the pages (unit of memory) that are written to.</p><p>Some applications pre-allocate memory (by which they mean touch it all &ndash; they write to it on startup so that it has mapped to physical memory). In those cases, RSS should be static, and this flame graph won\'t show many trace application events.</p><p>To be clear about this: page fault tracing can explain memory growth where the application may end up being out-of-memory (OOM) killed. It usually can\'t explain memory leaks where the application ends up calling garbage collection more frequently, since in those cases the application may or may not be growing RSS. This can only see RSS growth.</p><h4>Flame Graph Visualization</h4><p>The x-axis shows the stack profile population, sorted alphabetically (it is not the passage of time), and the y-axis shows stack depth. Each rectangle represents a stack frame. The wider a frame is is, the more often it was present in the profile. The top edge shows what directly triggered page faults, and beneath it is its ancestry. Different color hues are used for different code types, and the saturation is randomized to differentiate between frames.</p><h4>Common Issues</h4><p><b>Broken stacks:</b> If the runtime does not expose a stack walker that the profiler can use (commonly frame-pointer based), then stack traces will be broken and ancestry will be missing. This is usually visible as a "bed of grass": thin frames all at the same level. The fix depends on the runtime and stack walking technique. Eg, to use frame-pointer walking with Java, Java must be run with -XX:+PreserveFramePointer.</p><p><b>Missing frames:</b> This shows the native stack trace, after inlining. Runtimes like the JVM can inline as much as 70% of all frames, which will be missing from the fla me graph. Vector has an uninlined CPU flame graph task that can reveal these missing frames.</p><p><b>Missing symbols:</b> JIT runtimes need to export a symbol file for the profiler to use. This depends on the runtime. Java should be handled automatically by Vector, making use of perf-map-agent. Node.js currently needs to run with --perf_basic_prof_only_funcitons or --perf_basic_prof.</p><h4>Externel Resources</h4><ul><li>The <a href=http://www.brendangregg.com/flamegraphs.html>Flame Graphs homepage</a> has a page on <a href=http://www.brendangregg.com/FlameGraphs/memoryflamegraphs.html>Memory Flame Graphs</a>, which includes a section on page fault tracing.</li><li>There is an ACMQ article <a href="http://queue.acm.org/detail.cfm?id=2927301">The Flame Graph</a>, also published in <a href=http://cacm.acm.org/magazines/2016/6/202665-the-flame-graph/abstract>CACM</a>.</li></ul>'),e.put("app/components/pagefaultflamegraphtask/pagefaultflamegraph.html",'<div class=col-md-12><div class=row style="text-align: center"><p>Page fault stack tracing</p><button type=button class="btn btn-primary" ng-disabled=processing ng-click=generatePagefaultFlameGraph()>Generate Pagefault Flame Graph<i ng-if=processing class="fa fa-refresh fa-spin"></i></button> seconds:<select class=select ng-model=secondselected style=margin-top:7px><option ng-repeat="x in secondoptions">{{x}}</option></select></div><div class=row style="margin-top: 10px">Status: {{statusmsg}}</div><div class=row ng-if="!processing && ready" style="text-align: center; margin-top: 15px"><p>The flame graph is ready. Please click on the button below to open it.</p><a class="btn btn-default" href=http://{{host}}:{{port}}/{{svgname}} target=_blank>Open Flame Graph</a></div></div>'),e.put("app/components/pnamecpuflamegraphtask/pnamecpuflamegraph-help.html",'<h4>Summary</h4><p>Package name flame graphs visualize code that is directly consuming CPUs, and visualizes this as a hierarchy based on the package name (currently only supports Java package names). This widget works using a profiler that does timed sampling of the instruction pointer at 49 Hertz, on all running CPUs. This does not need the application to support stack traces, as it only measures the running function (ie, for Java, this does not need -XX:+PreserveFramePointer, so this can be useful for analyzing applications that are running without it). It runs as a background task until the profile is completed.</p><p></p><h4>Overhead</h4><p>This should have negligible overhead while profiling, and then a short period (seconds) of a single CPU runtime at the end as symbols are collected and the flame graph generated.</p><h4>CPU IP Profiling</h4><p>Timed sampling of the instruction pointer (aka program counter) is a common industry method for understanding CPU usage with very low overhead. This is different to tracing of all functions/methods, which is performed by some CPU profilers and costs high overhead and often skews results (observer effect). This is also different to profiling stack traces, as is typical with flame graphs. In this case, the stack trace is not collected, so code ancestry is not known or shown. The advantage is a different view of CPU consumption, that can be used in addition to normal flame graphs.</p><h4>Flame Graph Visualization</h4><p>The x-axis shows the stack profile population, sorted alphabetically (it is not the passage of time), and the y-axis in this case traverses components of the function or method package name. Each rectangle represents a component of the function or method name. The wider a frame is is, the more often it was present in the profile. The top edge shows the functions that are on-CPu, and beneath them are the larger package groups that they belong to. Different color hues are used for different code types, and the saturation is randomized to differentiate between frames.</p><h4>Common Issues</h4><p><b>Missing symbols:</b> JIT runtimes need to export a symbol file for the profiler to use. This depends on the runtime. Java should be handled automatically by Vector, making use of perf-map-agent. Node.js currently needs to run with --perf_basic_prof_only_funcitons or --perf_basic_prof.</p><h4>Externel Resources</h4><ul><li>A post on <a href=http://www.brendangregg.com/blog/2017-06-30/package-flame-graph.html>Package Name Flame Graphs</a>.</li><li>The <a href=http://www.brendangregg.com/flamegraphs.html>Flame Graphs homepage</a>.</li><li>An ACMQ article <a href="http://queue.acm.org/detail.cfm?id=2927301">The Flame Graph</a>, also published in <a href=http://cacm.acm.org/magazines/2016/6/202665-the-flame-graph/abstract>CACM</a>.</li></ul>'),e.put("app/components/pnamecpuflamegraphtask/pnamecpuflamegraph.html",'<div class=col-md-12><div class=row style="text-align: center"><p>Timed CPU IP sampling</p><button type=button class="btn btn-primary" ng-disabled=processing ng-click=generatePNameCPUFlameGraph()>Generate Package Name CPU Flame Graph<i ng-if=processing class="fa fa-refresh fa-spin"></i></button> seconds:<select class=select ng-model=secondselected style=margin-top:7px><option ng-repeat="x in secondoptions">{{x}}</option></select></div><div class=row style="margin-top: 10px">Status: {{statusmsg}}</div><div class=row ng-if="!processing && ready" style="text-align: center; margin-top: 15px"><p>The CPU flame graph is ready. Please click on the button below to open it.</p><a class="btn btn-default" href=http://{{host}}:{{port}}/{{svgname}} target=_blank>Open Flame Graph</a></div></div>'),e.put("app/components/uninlinedcpuflamegraphtask/uninlinedcpuflamegraph-help.html",'<h4>Summary</h4><p>Uninlined CPU flame graphs visualize code that is consuming CPUs, and attempts to uninline application frames so that full stacks are shown (currently only supports Java). This widget works using a profiler that does timed sampling of stack traces at 49 Hertz, on all running CPUs. It runs as a background task until the profile is completed.</p><p></p><h4>Overhead</h4><p>This should have negligible overhead while profiling, and then a short period (seconds) of a single CPU runtime at the end as symbols are collected and the flame graph generated.</p><h4>CPU Profiling</h4><p>Timed sampling of stack traces is a common industry method for understanding CPU usage with low overhead. This is different to tracing of all functions/methods, which is performed by some CPU profilers and costs high overhead and often skews results (observer effect).</p><h4>Flame Graph Visualization</h4><p>The x-axis shows the stack profile population, sorted alphabetically (it is not the passage of time), and the y-axis shows stack depth. Each rectangle represents a stack frame. The wider a frame is is, the more often it was present in the profile. The top edge shows what is on-CPU, and beneath it is its ancestry. Different color hues are used for different code types, and the saturation is randomized to differentiate between frames.</p><h4>Common Issues</h4><p><b>Broken stacks:</b> If the runtime does not expose a stack walker that the profiler can use (commonly frame-pointer based), then stack traces will be broken and ancestry will be missing. This is usually visible as a "bed of grass": thin frames all at the same level. The fix depends on the runtime and stack walking technique. Eg, to use frame-pointer walking with Java, Java must be run with -XX:+PreserveFramePointer.</p><p><b>Missing symbols:</b> JIT runtimes need to export a symbol file for the profiler to use. This depends on the runtime. Java should be handled automatically by Vector, making use of perf-map-agent. Node.js currently needs to run with --perf_basic_prof_only_funcitons or --perf_basic_prof.</p><h4>Externel Resources</h4><ul><li>The <a href=http://www.brendangregg.com/flamegraphs.html>Flame Graphs homepage</a> has a page on <a href=http://www.brendangregg.com/FlameGraphs/cpuflamegraphs.html>CPU Flame Graphs</a>.</li><li>There is an ACMQ article <a href="http://queue.acm.org/detail.cfm?id=2927301">The Flame Graph</a>, also published in <a href=http://cacm.acm.org/magazines/2016/6/202665-the-flame-graph/abstract>CACM</a>.</li></ul>'),e.put("app/components/uninlinedcpuflamegraphtask/uninlinedcpuflamegraph.html",'<div class=col-md-12><div class=row style="text-align: center"><p>Timed CPU stack sampling</p><button type=button class="btn btn-primary" ng-disabled=processing ng-click=generateUninlinedCPUFlameGraph()>Generate Uninlined CPU Flame Graph<i ng-if=processing class="fa fa-refresh fa-spin"></i></button> seconds:<select class=select ng-model=secondselected style=margin-top:7px><option ng-repeat="x in secondoptions">{{x}}</option></select></div><div class=row style="margin-top: 10px">Status: {{statusmsg}}</div><div class=row ng-if="!processing && ready" style="text-align: center; margin-top: 15px"><p>The CPU flame graph is ready. Please click on the button below to open it.</p><a class="btn btn-default" href=http://{{host}}:{{port}}/{{svgname}} target=_blank>Open Flame Graph</a></div></div>')}]);
//# sourceMappingURL=../maps/scripts/app-ef1fadcfe5.js.map
